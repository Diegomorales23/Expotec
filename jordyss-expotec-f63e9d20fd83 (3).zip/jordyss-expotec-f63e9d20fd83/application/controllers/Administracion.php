<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administracion extends MY_Controller  {

  public $modeloUsuario;
  public $nombreControlador = 'Administracion/';

  public function __construct()
	{
		parent::__construct();
	}

	public function Principal(){
    parent::ObtenerMasterPage($this->nombreControlador . 'principal');
	}

  public function EditarDatosUsuario(){
    $resultado = $this->ObtenerUsuarioPorId();
    parent::ObtenerMasterPage('EditarDatosUsuario',null,'usuario',$resultado);
  }

  public function ObtenerUsuarioPorId(){
 	  $this->load->model('UsuarioModel');
 	  $this->modeloUsuario = new UsuarioModel;
    $id = $this->session->userdata['logged_in']['id'];
    $this->load->model('UsuarioModel');
    $this->modeloUsuario = new UsuarioModel;
    $resultado = $this->modeloUsuario->ObtenerUsuarioPorId($id);

    return $resultado;
  }

  public function ActualizarUsuario(){
    $id = $this->input->post('id');
    $nombre = $this->input->post('nombre');
    $apellidos = $this->input->post('apellidos');
    $clave = $this->input->post('clave');
    $correo = $this->input->post('correo');
    $idEstado = $this->input->post('idEstado');
    $idPerfil = $this->input->post('idPerfil');

    $data = array(
      'id' => $id,
      'nombre' => $nombre,
      'apellidos' => $apellidos,
      'clave' => do_hash($clave,'md5'),
      'correo' => $correo,
      'idUsuarioModificado'  => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s'),
      'idEstado' => $idEstado,
      'idPerfil' => $idPerfil //Es un id para perfil temporal
    );

    $this->load->model('UsuarioModel');
    $this->modeloUsuario = new UsuarioModel;
    $resultado = $this->modeloUsuario->ActualizarUsuario($data,$id);

    return $resultado;
  }
}
