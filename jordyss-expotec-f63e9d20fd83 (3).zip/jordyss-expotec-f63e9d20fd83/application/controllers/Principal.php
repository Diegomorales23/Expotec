<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Principal extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Codeigniter : Write Less Do More

		$this->load->library('form_validation');
		$this->load->library('session');
	}

	public function index()
	{
	//	$this->Email = new EnviarEmail;
		//$this->Email->EnviarCorreo('jordy.segura07@gmail.com');
		$this->load->view('principal');
	}

	public function recuperarContrasenia()
	{
		$this->load->view('Layout/recuperarContrasenia');
	}

	public function registrarse()
	{
		$this->load->view('Layout/registrarse');
	}

	public function EnviarRegistro()
	{
		$this->load->view('');
	}

}
