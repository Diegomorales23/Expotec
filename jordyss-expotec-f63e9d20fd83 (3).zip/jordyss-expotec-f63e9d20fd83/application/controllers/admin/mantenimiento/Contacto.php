<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require_once APPPATH . 'models/Contacto.php';

class Contacto extends MY_Controller  {

  public $modeloContacto;
  public $rutaControlador = 'Administracion/Mantenimientos/Contacto/';

  public function __construct()
	{
		parent::__construct();
	}

  /********** MANTENIMIENTO DE CONTACTOS **********
  /*
    Mantenimiento de los contactos CRUD
  */
  /**********                    **********/
  public function Contacto(){
    $resultado = $this->ObtenerContacto();
    parent::ObtenerMasterPage($this->rutaControlador . 'contacto','contacto.js','contactos',$resultado);
  }

  public function AgregarContacto(){
    parent::ObtenerMasterPage($this->rutaControlador .  'agregarContacto','contacto.js');
  }

  public function ObtenerContacto(){
    $this->load->model('ContactoModel');
    $this->modeloContacto = new ContactoModel;
    $resultado = $this->modeloContacto->ObtenerContacto();
    return $resultado;
  }

  public function ObtenerContactoPorId(){
    $id = $this->input->post('id');
    $this->load->model('ContactoModel');
    $this->modeloContacto = new ContactoModel;
    $resultado = $this->modeloContacto->ObtenerContactoPorId($id);

    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function InsertarContacto(){

        $nombre = $this->input->post('nombre');
        $correo = $this->input->post('correo');

        if ($nombre == '' or $correo == '' ){
                $arr = array('mensaje' => ERROR_DATOS_REQUERIDOS, 'accion' => 'error');
                header('Content-Type: application/json');
                echo json_encode($arr);
                return;
        }

          $data = array(
            'nombre' => $nombre,
            'correo' => $correo,
            'fecha' => date('Y-m-d H:i:s'),
            'idUsuarioCreado'  => $this->session->userdata['logged_in']['id'],
            'fechaCreado' => date('Y-m-d H:i:s'),
            );

        $this->load->model('ContactoModel');
        $this->modeloContacto = new ContactoModel;
        $resultado = $this->modeloContacto->InsertarContacto($data);
        $arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode( $arr );

  }

  public function ActualizarContacto(){
    $id = $this->input->post('id');
    $nombre = $this->input->post('nombre');
    $correo = $this->input->post('correo');

    $data = array(
      'nombre' => $nombre,
      'correo' => $correo,
      'idUsuarioModificado'  => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s'),
    );

    $this->load->model('ContactoModel');
    $this->modeloContacto = new ContactoModel;
    $resultado = $this->modeloContacto->ActualizarContacto($data,$id);
    $arr = array('mensaje' => ACTUALIZAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  public function EliminarContacto(){
    $id = $this->input->post('id');
    $this->load->model('ContactoModel');
    $this->modeloContacto = new ContactoModel;
    $resultado = $this->modeloContacto->EliminarContacto($id);
    $arr = array('mensaje' => ELIMINAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

}
