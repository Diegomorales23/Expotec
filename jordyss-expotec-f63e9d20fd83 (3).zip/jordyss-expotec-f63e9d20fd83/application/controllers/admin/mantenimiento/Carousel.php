<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require_once APPPATH . 'models/Usuario.php';

class Carousel extends MY_Controller  {

  public $modeloUsuario;
  public $nombreControlador = 'Administracion/Mantenimientos/Carousel/';

  public function __construct()
	{
		parent::__construct();
	}

  /********** MANTENIMIENTO DE CAROUSEL **********
  /*
    Mantenimiento de los carousel CRUD
  */
  /**********                    **********/
  public function Carousel(){
    $resultado = $this->ObtenerCarousel();
    parent::ObtenerMasterPage($this->nombreControlador . '/principal','carousel.js','carousel',$resultado);
  }

  public function InsertarCarousel()
  {
    $nombre = $this->input->post('nombre');
    $url = $_FILES;
    $esAutomatico = $this->input->post('esAutomatico');
    $idEstado = 1;

    $data = array(
      'nombre' => $nombre,
      'urlImagen' => $_FILES,
      'esAutomatico' => 1,
      'idEstado' => $idEstado,
      'idUsuarioCreado' => $this->session->userdata['logged_in']['id'],
      'fechaCreado' => date('Y-m-d H:i:s'),
    );

    if(!$this->ValidarDatos($data)){
      $urlImagen = $this->CargaImagen($url['imagen']['tmp_name']);
      $data['urlImagen'] = $urlImagen;

      $this->load->model('CarouselModel');
      $this->modeloCarousel = new CarouselModel;
      $resultado = $this->modeloCarousel->InsertarCarousel($data);
    }

    return $this->Carousel();
  }

  public function ObtenerCarousel()
  {
    $this->load->model('CarouselModel');
    $this->modeloCarousel = new CarouselModel;
    $resultado = $this->modeloCarousel->ObtenerCarousel();
    return $resultado;
  }

  public function CargaImagen($imagen){
    $content = file_get_contents($imagen);
    $rutaImagen = '/publico/md_'.uniqid().'.jpg';
    file_put_contents(FCPATH . $rutaImagen, $content);

    return $rutaImagen;
    }

    public function ValidarDatos($datos){
      if(in_array(null, $datos))
      {
        return true;
      }
      return false;
    }

}
