<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perfil extends MY_Controller  {

	public $modeloPerfil;
	public $rutaControlador = 'Administracion/Mantenimientos/Perfil/';

  public function __construct(){
		parent::__construct();
	}

	public function Principal(){
    	$resultado = $this->ObtenerPerfiles();
    	parent::ObtenerMasterPage($this->rutaControlador . 'principal','perfil.js','perfiles',$resultado);
  }

  public function AgregarPerfiles(){
    parent::ObtenerMasterPage($this->rutaControlador .  'agregarPerfil','perfil.js');
  }

  /********** MANTENIMIENTO DE USUARIOS **********
  /*
    Mantenimiento de los usuarios CRUD
  */
  /**********                    **********/
  public function ObtenerPerfiles(){
    $this->load->model('PerfilModel');
    $this->modeloPerfil = new PerfilModel;
    $resultado = $this->modeloPerfil->ObtenerPerfil();
    return $resultado;
  }

  public function ObtenerPerfilPorId(){
    $idPerfil = $this->input->post('idPerfil');
    $this->load->model('PerfilModel');
    $this->modeloPerfil = new PerfilModel;
    $resultado = $this->modeloPerfil->ObtenerPerfilPorId($idPerfil);

    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function InsertarPerfil(){

        $nombre = $this->input->post('nombre');
        $descripcion = $this->input->post('descripcion');
        $idEstado = $this->input->post('idEstado');

        if ($nombre == '' or $descripcion == '' or $idEstado == '' or $idUsuarioCreado == ''
        or $fechaCreado == ''){
                $arr = array('mensaje' => ERROR_DATOS_REQUERIDOS, 'accion' => 'error');
                header('Content-Type: application/json');
                echo json_encode($arr);
                return;
        }

          $data = array(
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'idEstado' => $idEstado,
            'idUsuarioCreado'  => $this->session->userdata['logged_in']['idUsuario'],
            'fechaCreado' => date('Y-m-d H:i:s'),
          );

        $this->load->model('PerfilModel');
        $this->modeloPerfil = new PerfilModel;
        $resultado = $this->modeloPerfil->InsertarPerfil($data);
        $arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode( $arr );

  }

  public function ActualizarPerfil(){
    $idPerfil = $this->input->post('idPerfil');
    $nombre = $this->input->post('nombre');
    $descripcion = $this->input->post('descripcion');
    $idEstado = $this->input->post('idEstado');

    $data = array(
      //'idPerfil' => $idPerfil,
      'nombre' => $nombre,
      'descripcion' => $descripcion,
      'idEstado' => $idEstado,
      'idUsuarioModificado'  => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s'),
    );

    $this->load->model('PerfilModel');
    $this->modeloPerfil = new PerfilModel;
    $resultado = $this->modeloPerfil->ActualizarPerfil($data,$idPerfil);
    $arr = array('mensaje' => ACTUALIZAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  public function EliminarPerfil(){
    $idPerfil = $this->input->post('idPerfil');

    $this->load->model('PerfilModel');
    $this->modeloPerfil = new PerfilModel;
    $resultado = $this->modeloPerfil->EliminarPerfil($idPerfil);
    $arr = array('mensaje' => ELIMINAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  /********** MANTENIMIENTO DE ESTADOS **********
  /*
    Mantenimiento de los estado CRUD
  */
  /**********                    **********/
  public function ObtenerEstado(){
    $this->load->model('Estado');
    $this->modeloEstado = new Estado;
    $resultado = $this->modeloEstado->ObtenerEstado();
    header('Content-Type: application/json');
    echo json_encode( $resultado );

  }
}
