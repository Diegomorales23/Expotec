<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rubrica extends MY_Controller  {

  public $modeloUsuario;

  public function __construct()
	{
		parent::__construct();
	}

  public function Rubrica(){
    $resultado = $this->ObtenerUsuarios();
    parent::ObtenerMasterPage('Mantenimiento/Usuario/usuario','usuarios.js','usuarios',$resultado);
  }

  public function AgregarRubrica(){
    parent::ObtenerMasterPage('Mantenimiento/Usuario/agregarUsuario','usuarios.js');
  }

 public function ObtenerRubrica()
  {
    $this->load->model('Rubrica');
    $this->modeloRubrica = new Rubrica;
    $resultado = $this->modeloRubrica->ObtenerRubrica();
    return $resultado;
  }

  public function ObtenerRubricaPorId()
  {
    $id = $this->input->post('idRubrica');
    $this->load->model('Rubrica');
    $this->modeloRubrica = new Rubrica;
    $resultado = $this->modeloRubrica->ObtenerRubricaPorId($idRubrica);

    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function InsertarRubrica()
  {
        $nombre = $this->input->post('nombre');
        $idArea = $this->input->post('idArea');

        if ($nombre == '' or $idArea==''){
                $arr = array('mensaje' => ERROR_DATOS_REQUERIDOS, 'accion' => 'error');
                header('Content-Type: application/json');
                echo json_encode($arr);
                return;
        }
          $data = array(
            'nombre' => $nombre,
            'idArea' => $idArea,
          );
        $this->load->model('Rubrica');
        $this->modeloRubrica = new Rubrica;
        $resultado = $this->modeloRubrica->InsertarRubrica($data);
        $arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode( $arr );
  }

  public function ActualizarRubrica()
  {
    $idRubrica = $this->input->post('idRubrica');
    $nombre = $this->input->post('nombre');
    $idUsuarioModificado = $this->input->post('idUsuarioModificado');
    $fechaModificado = $this->input->post('fechaModificado');

    $data = array(
      'idRubrica' => $idRubrica,
      'nombre' => $nombre,
      'idUsuarioModificado'  => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s')
    );

    $this->load->model('Rubrica');
    $this->modeloRubrica = new Rubrica;
    $resultado = $this->modeloRubrica->ActualizarRubrica($data,$idRubrica);
    $arr = array('mensaje' => ACTUALIZAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

   public function EliminarRubrica()
  {
    $id = $this->input->post('id');

    $this->load->model('Rubrica');
    $this->modeloRubrica = new Rubrica;
    $resultado = $this->modeloRubrica->EliminarRubrica($id);
    $arr = array('mensaje' => ELIMINAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }
}
