<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class area extends MY_Controller  {

  public function __construct()
	{
		parent::__construct();
		$this->load->model("AreaModel");
	}

	public function Principal()
	{
		$resultado = $this->AreaModel->getCoordinadores();
		$data = array('coordinadores' => $resultado);
		parent::ObtenerMasterPage('Administracion/Mantenimientos/Area/Areas', 'Areas.js','coordinadores',$resultado);
	}

	public function InsertarArea()
	{
		$pNombre =  $this->input->post('txtNombreArea');
		$pDescripcion =  $this->input->post('txtDescripcion');
		$pipdCoordinador =  $this->input->post('ddCoordinador');

	    $Parametros = array(
							 'pnombre' => $pNombre,
							 'pDescripcion' => $pDescripcion,
							 'pidCoordinador' => $pipdCoordinador
        );
		var_dump($Parametros);
		$resultado = $this->AreaModel->insertAreas($Parametros);
		$arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode( $arr );
	}

	public function ActualizaArea()
	{
		$idArea =  $this->input->post('idArea');
		$pNombre =  $this->input->post('txtNombreArea');
		$pDescripcion =  $this->input->post('txtDescripcion');
		$pipdCoordinador =  $this->input->post('ddCoordinador');

	    $Parametros = array(
							 'P_ID_Area' => $idArea,
							 'P_Nombre' => $pNombre,
							 'P_Descripcion' => $pDescripcion,
							 'P_ID_Coordinador' => $pipdCoordinador
		);
		var_dump($Parametros);
		$resultado = $this->AreaModel->actualizarArea($Parametros);
		var_dump($resultado);
		$arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode($arr);
	}
    public function AreaTable()
	{
		 // Datatables Variables
		 $draw = intval($this->input->get("draw"));
		 $start = intval($this->input->get("start"));
		 $length = intval($this->input->get("length"));
		 $areas = $this->AreaModel->getAreas();

		 $data = array();

		 foreach($areas as $r) {

			  $data[] = array(
				   $r->idArea,
				   $r->Nombre,
				   $r->Descripcion,
				   $r->NombreCoordinador,
				   $r->IdCoordinador,
				   ""
			  );
		 }

		 $output = array(
			  "draw" => $draw,
				"recordsTotal" => count($areas),
				"recordsFiltered" => count($areas),
				"data" => $areas
		   );
		 echo json_encode($output);
		 exit();
	}

	public function EliminaArea()
	{
		$idArea =  $this->input->post('pidArea');

	    $Parametros = array(
							 'pidArea' => $idArea
        );
		var_dump($Parametros);
		$resultado = $this->AreaModel->EliminaAreas($Parametros);
		$arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode( $arr );
	}
}
