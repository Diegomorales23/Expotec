<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require_once APPPATH . 'models/Usuario.php';

class Usuario extends MY_Controller  {

  public $modeloUsuario;
  public $rutaControlador = 'Administracion/Mantenimientos/Usuario/';

  public function __construct()
	{
		parent::__construct();
	}

  public function Principal(){
    $resultado = $this->ObtenerUsuarios();
    parent::ObtenerMasterPage($this->rutaControlador . 'principal','usuarios.js','usuarios',$resultado);
  }

  public function AgregarUsuario(){
    parent::ObtenerMasterPage($this->rutaControlador .  'agregarUsuario','usuarios.js');
  }

  /********** MANTENIMIENTO DE USUARIOS **********
  /*
    Mantenimiento de los usuarios CRUD
  */
  /**********                    **********/
  public function ObtenerUsuarios(){
    $this->load->model('UsuarioModel');
    $this->modeloUsuario = new UsuarioModel;
    $resultado = $this->modeloUsuario->ObtenerUsuarios();
    return $resultado;
  }

  public function ObtenerUsuarioPorId(){
    $id = $this->input->post('idUsuario');
    $this->load->model('UsuarioModel');
    $this->modeloUsuario = new UsuarioModel;
    $resultado = $this->modeloUsuario->ObtenerUsuarioPorId($id);

    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function InsertarUsuario(){

        $nombre = $this->input->post('nombre');
        $apellidos = $this->input->post('apellido1');
        $clave = $this->input->post('clave');
        $correo = $this->input->post('correo');
        $idEstado = $this->input->post('idEstado');
        $idPerfil = $this->input->post('idPerfil');

        if ($nombre == '' or $apellidos == '' or $clave == '' or $correo == ''
        or $idEstado == '' or $idPerfil == '' ){
                $arr = array('mensaje' => ERROR_DATOS_REQUERIDOS, 'accion' => 'error');
                header('Content-Type: application/json');
                echo json_encode($arr);
                return;
        }


          $data = array(
            'nombre' => $nombre,
            'apellido1' => $apellidos,
            'clave' => do_hash($clave,'md5'),
            'correo' => $correo,
            'idUsuarioCreado'  => $this->session->userdata['logged_in']['id'],
            'fechaCreado' => date('Y-m-d H:i:s'),
            'idEstado' => $idEstado,//Estado pendiente de aprobacion
            'idPerfil' => $idPerfil //Es un id para perfil temporal
          );

        $this->load->model('UsuarioModel');
        $this->modeloUsuario = new UsuarioModel;
        $this->modeloUsuario->InsertarUsuario($data);
/*
        $dataB = array(
          'accion' => 'insertar',
          'valorNuevo' => $nombre . ' ' . $nombre . ' ' . $correo,
          'valorViejo' => "",

          'idUsuarioCreado'  => $this->session->userdata['logged_in']['id'],
          'fechaCreado' => date('Y-m-d H:i:s'),
          'idUsuarioModificado' => '',
          'fechaModificado' => ''
        );

        $this->load->model('BitacoraModel');
        $this->modeloBita = new BitacoraModel;
        $this->modeloBita->InsertarBitacora($dataB);
*/

        $arr = array('mensaje' => INSERTAR_DATOS_EXITO, 'accion' => 'success');
        header('Content-Type: application/json');
        echo json_encode( $arr );

  }

  public function ActualizarUsuario(){
    $id = $this->input->post('idUsuario');
    $nombre = $this->input->post('nombre');
    $apellidos = $this->input->post('apellido1');
    $clave = $this->input->post('clave');
    $correo = $this->input->post('correo');
    $idEstado = $this->input->post('idEstado');
    $idPerfil = $this->input->post('idPerfil');


    $data = array(
      'idUsuario' => $id,
      'nombre' => $nombre,
      'apellido1' => $apellidos,
      'apellido2' => $apellidos,
      'clave' => do_hash($clave,'md5'),
      'correo' => $correo,
      'idUsuarioModificado'  => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s'),
      'idEstado' => $idEstado,
      'idPerfil' => $idPerfil //Es un id para perfil temporal
    );

    $this->load->model('UsuarioModel');
    $this->modeloUsuario = new UsuarioModel;
    $resultado = $this->modeloUsuario->ActualizarUsuario($data,$id);
    $arr = array('mensaje' => ACTUALIZAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  public function EliminarUsuario(){
    $id = $this->input->post('idUsuario');

    $this->load->model('UsuarioModel');
    $this->modeloUsuario = new UsuarioModel;
    $resultado = $this->modeloUsuario->EliminarUsuario($id);
    $arr = array('mensaje' => ELIMINAR_DATOS_EXITO, 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  /********** MANTENIMIENTO DE USUARIOS **********
  /*
    Mantenimiento de los perfil CRUD
  */
  /**********                    **********/
  public function ObtenerPerfil(){
    $this->load->model('PerfilModel');
    $this->modeloPerfil = new PerfilModel;
    $resultado = $this->modeloPerfil->ObtenerPerfil();
    header('Content-Type: application/json');
    echo json_encode( $resultado );

  }

  /********** MANTENIMIENTO DE ESTADOS **********
  /*
    Mantenimiento de los estado CRUD
  */
  /**********                    **********/
  public function ObtenerEstado(){
    $this->load->model('Estado');
    $this->modeloEstado = new Estado;
    $resultado = $this->modeloEstado->ObtenerEstado();
    header('Content-Type: application/json');
    echo json_encode( $resultado );

  }

}
