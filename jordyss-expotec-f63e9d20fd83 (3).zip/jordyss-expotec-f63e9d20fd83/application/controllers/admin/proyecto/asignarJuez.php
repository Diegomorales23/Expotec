<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class asignacionJuez extends MY_Controller  {


  public $modeloasignacionJuez;
  public $nombreControlador = 'Administracion/Proyecto/asignacionJuez/';

  public function __construct(){
    parent::__construct();
  }

  public function Principal(){
    parent::ObtenerMasterPage($this->nombreControlador . 'Administracion/Proyecto/asignacionJuez/','asignacionJuez.js');
  }

  

public function InsertarAsignar(){

    
    $idJuez = $this->input->post('idJuez');
    $proyecto = $this->input->post('proyecto');
    $año = $this->input->post('año');
    
    $data = array(

      'idJuez'=> $idJuez,
      'idProyecto' => $idproyecto,
      'año'=>$año,
      'idUsuarioCreado' => $this->session->userdata['logged_in']['id'],
      'fechaCreado' => date('Y-m-d H:i:s'),
      
    );


  public function ObtenerAsignar(){
    $this->load->model('asignacionJuez');
    $this->asignacionJuez = new asignacionJuez;
    $resultado = $this->asignacionJuez->ObtenerAsignar();
    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function ObtenerAsignarPorId(){
    $id = $this->input->post('id');
    $this->load->model('asignacionJuez');
    $this->asignacionJuez = new asignacionJuez;
    $resultado = $this->asignacionJuez->ObtenerAsignarPorId($id);
    var_dump($resultado);
    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function ActualizarAsignar(){
    $id = $this->input->post('id');
    $idProyecto = $this->input->post('idProyecto');
    $año = $this ->input->post('año');


    $data = array(
      'id' => $id,
      'idEventoModificado'  => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s'),
      'idProyecto' => $idProyecto,
      'año'=> $año
      
    );

    $this->load->model('asignacionJuez');
    $this->asignacionJuez = new asignacionJuez;
    $resultado = $this->asignacionJuez->ActualizarAsignar($data,$id);
    $arr = array('mensaje' => 'Datos actualizados correctamente.', 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  public function EliminarAsignar(){
    $id = $this->input->post('id');

    $this->load->model('asignacionJuez');
    $this->asignacionJuez = new asignacionJuez;
    $resultado = $this->asignacionJuez->EliminarAsignar($id);
    $arr = array('mensaje' => 'Datos eliminados correctamente.', 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }


}