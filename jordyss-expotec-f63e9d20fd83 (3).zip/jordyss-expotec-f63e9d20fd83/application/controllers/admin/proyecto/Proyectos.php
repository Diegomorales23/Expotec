<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Proyectos extends MY_Controller  {

  public function __construct()
	{
		parent::__construct();
		$this->load->model("ProyectoModel");
	}

	public function Principal()
	{
        $resultado = $this->ProyectoModel->getAreas();
		$data = array('area' => $resultado);
		parent::ObtenerMasterPage('Administracion/Proyecto/CrearProyecto','Proyectos.js',null,null,$data);
    }

    public function GuardarProyecto(){
		$pNombre =  $this->input->post('Nombre');
		$pArea =  $this->input->post('idArea');
		$pDescripcion =  $this->input->post('Descripcion');
		$pGrado =  $this->input->post('Grado');

		$Parametros = array(
			'p_nombre' => $pNombre,
			'p_idArea' => $pArea,
			'p_grado' => $pGrado, 
			'p_descripcion' => $pDescripcion
		);
		var_dump($Parametros);
		$resultado = $this->ProyectoModel->guardaProyecto($Parametros);
	}
	
	public function AsignaIntegrante(){
		$pidUsuario =  $this->input->post('idUsuario');
		$pidProyecto =  $this->input->post('idProyecto');

		$Parametros = array(
			'p_idUsuario' => $pNombre,
			'p_idProyecto' => $pArea
		);
		var_dump($Parametros);
		$resultado = $this->ProyectoModel->asignaIntegrante($Parametros);
    }
}