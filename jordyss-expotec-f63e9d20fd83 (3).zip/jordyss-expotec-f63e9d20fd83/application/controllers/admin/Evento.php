<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Evento extends MY_Controller  {

  public $modeloEvento;
  public $nombreControlador = 'Administracion/Evento/';

  public function __construct(){
		parent::__construct();
	}

	public function Principal(){
    $resultado = $this->ObtenerEventos();
    parent::ObtenerMasterPage($this->nombreControlador . 'principal','evento.js','eventos',$resultado);
	}

  /********** MANTENIMIENTO DE EVENTOS **********
  /*
    Mantenimiento de los eventos CRUD
  */
  /**********                    **********/
  public function InsertarEvento(){

    $titulo = $this->input->post('titulo');
    $horario = $this->input->post('horario');
    $lugar = $this->input->post('lugar');
    $cupo = $this->input->post('cupo');
    $estado = $this->input->post('estado');
    $imagen = $_FILES;
    $descripcion = $this->input->post('descripcion');

    $data = array(
      'titulo' => $titulo,
      'horario' => $horario,
      'lugar' => $lugar,
      'cupos' => $cupo,
      'idEstado'  => $estado,
      'idUsuarioCreado' => $this->session->userdata['logged_in']['id'],
      'fechaCreado' => date('Y-m-d H:i:s'),
      'imagen' => $imagen,
      'descripcion' => $descripcion
    );

    if(!$this->ValidarDatos($data)){
      $urlImagen = $this->CargaImagen($imagen['imagen']['tmp_name']);
      $data['imagen'] = $urlImagen;

      $this->load->model('EventoModel');
      $this->modeloEvento = new EventoModel;
      $resultado = $this->modeloEvento->InsertarEvento($data);
    }

    $this->Principal();
  }

  public function ObtenerEventos(){
    $this->load->model('EventoModel');
    $this->modeloEvento = new EventoModel;
    $resultado = $this->modeloEvento->ObtenerEventos();
    return $resultado;
  }

  public function ObtenerEventoPorId(){
    $id = $this->input->post('idEvento');
    $this->load->model('EventoModel');
    $this->modeloEvento = new EventoModel;
    $resultado = $this->modeloEvento->ObtenerEventoPorId($id);
    header('Content-Type: application/json');
    echo json_encode($resultado);
  }

  public function ActualizarEvento(){
    $id = $this->input->post('idEvento');
    $titulo = $this->input->post('titulo');
    $horario = $this->input->post('horario');
    $lugar = $this->input->post('lugar');
    $cupo = $this->input->post('cupo');
    $estado = $this->input->post('estado');
    $descripcion = $this->input->post('descripcion');

    $data = array(
      'titulo' => $titulo,
      'horario' => $horario,
      'lugar' => $lugar,
      'fechaCreacion' => date('Y-m-d H:i:s'),
      'cupos' => $cupo,
      'idEstado'  => $estado,
      'idUsuarioModificado' => $this->session->userdata['logged_in']['id'],
      'fechaModificado' => date('Y-m-d H:i:s'),
      'descripcion' => $descripcion
    );

    $this->load->model('EventoModel');
    $this->modeloEvento = new EventoModel;
    $resultado = $this->modeloEvento->ActualizarEvento($data,$id);
    $arr = array('mensaje' => 'Datos actualizados correctamente.', 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  public function EliminarEvento(){
    $id = $this->input->post('idEvento');
    //unlink( FCPATH . 'publico/' . $group_picture );
    $this->load->model('EventoModel');
    $this->modeloEvento = new EventoModel;
    $resultado = $this->modeloEvento->EliminarEvento($id);
    $arr = array('mensaje' => 'Datos eliminados correctamente.', 'accion' => 'success');
    header('Content-Type: application/json');
    echo json_encode( $arr );
  }

  public function CargaImagen($imagen){
    $content = file_get_contents($imagen);
    $rutaImagen = '/publico/md_'.uniqid().'.jpg';
    file_put_contents(FCPATH . $rutaImagen, $content);

    return $rutaImagen;
    }

  public function ValidarDatos($datos){
    if(in_array(null, $datos))
    {
      return true;
    }
    return false;
  }
}
