<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {

	public $modeloUsuario;

	public function __construct() {
	 parent::__construct();

	 $this->load->library('form_validation');
	 $this->load->model('UsuarioModel');
	 $this->modeloUsuario = new UsuarioModel;
}

	public function Index()
	{
		$this->load->view('Layout/login');
	}

	/*
		Metodo que envia datos de ingreso y pregunta en bd para
		crear la sesion en caso de que exista.
	*/
	public function Ingresar()
	{
		$this->form_validation->set_rules('correo', 'correo', 'required');
    $this->form_validation->set_rules('clave', 'clave', 'required');

		if ($this->form_validation->run() == FALSE){
            $this->session->set_flashdata('error', ERROR_DATOS_REQUERIDOS);
            redirect(base_url('login'));
        }else{
						$varResultado = $this->modeloUsuario->VerificarUsuario();

						if (empty($varResultado))
						{
							$this->session->set_flashdata('error', ERROR_SISTEMA);
							redirect(base_url('login'));
						}
						else
						{
							$varListaPermisos = $this->modeloUsuario->ObtenerPermisosPerfil($varResultado->idPerfil);
							$varPermisos = '';
							$count = 0;

							foreach ($varListaPermisos as $row) {
								if($count == 0)
										$varPermisos = trim($row->idPermiso);
								else
										$varPermisos = $varPermisos . ',' . trim($row->idPermiso);
								$count = $count + 1;
							}

								$session_data = array(
									 'id' => $varResultado->idUsuario,
									 'nombre' => $varResultado->nombre . ' ' . $varResultado->apellido1 ,
									 'perfil' => $varResultado->idPerfil,
									 'ListaPermisos' => $varPermisos
								 );

								 $this->session->set_userdata('logged_in', $session_data);
						}

						redirect(base_url('Administracion/principal'));
        }
	}

	/*
		Metodo que envia los datos de contraseña para la recuperacion de su sesion
		al correo del usuario que lo solicita
	*/
	public function RecuperarContrasenia()
	{
		$correo = $this->input->post('correo');
    $resultado = parent::EnviarCorreo($correo,'prueba','Prueba email recuperar','hola esto es una prueba ja',SOLICITUD_CAMBIO_CLAVE_CORREO);
		$this->session->set_flashdata('mensaje', $resultado);
		redirect(base_url() . 'recuperarContrasenia');
	}

	/*
		Metodo que envia los datos llenados por el usaurio a base de datos para
		porsteriormente ser aceptados por el usuario adminstrador
	*/
	public function Registrarse()
	{
		$this->load->view('Administracion/principal');
	}

	/*
		Metodo que envia los datos llenados por el usaurio a base de datos para
		porsteriormente ser aceptados por el usuario adminstrador
	*/
	public function CerrarSesion()
	{
		if($this->session->userdata['logged_in'])
		{
			$sess_array = array(
			'username' => ''
			);
			$this->session->unset_userdata('logged_in', $sess_array);
			echo '<script>window.location="'.base_url().'login'.'"</script>';
		}

		redirect(base_url());
	}

}
