<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'principal';
$route['404_override'] = '';
$route['login'] = 'login/index'; //Primer pantalla para ingresar los datos de login (correo y pass)
$route['ingresar'] = 'login/ingresar'; //Llama la bd para crear la sesion y redireccionar al banner adminstrativo
$route['salir'] = 'login/cerrarsesion'; //Llama al controlador para cerrar la sesion

$route['registrarse'] = 'principal/registrarse'; //Primer pantalla para el formulario de registro
$route['registrarse/enviar'] = 'login/registrarse'; //Envia los datos de registro a bd

$route['recuperarContrasenia'] = 'principal/recuperarContrasenia'; //Primer pantalla para el formulario de recuperacion de contraseña
$route['recuperarContrasenia/enviar'] = 'login/recuperarContrasenia'; //Envia el correo al usuario para recuperar contraseña
$route['translate_uri_dashes'] = FALSE;

/*Rutas de las pantallas*/
/*Mantenimiento usuario*/
$route['mantenimiento/usuario'] = 'admin/mantenimiento/usuario/principal';
$route['mantenimiento/agregarusuario'] = 'admin/mantenimiento/usuario/agregarusuario';
$route['mantenimiento/usuario/ObtenerUsuarioPorId'] = 'admin/mantenimiento/usuario/ObtenerUsuarioPorId';
$route['mantenimiento/usuario/ObtenerUsuarios'] = 'admin/mantenimiento/usuario/ObtenerUsuarios';
$route['mantenimiento/usuario/InsertarUsuario'] = 'admin/mantenimiento/usuario/InsertarUsuario';
$route['mantenimiento/usuario/ActualizarUsuario'] = 'admin/mantenimiento/usuario/ActualizarUsuario';
$route['mantenimiento/usuario/EliminarUsuario'] = 'admin/mantenimiento/usuario/EliminarUsuario';
$route['mantenimiento/usuario/ObtenerPerfil'] = 'admin/mantenimiento/usuario/ObtenerPerfil';
$route['mantenimiento/usuario/ObtenerEstado'] = 'admin/mantenimiento/usuario/ObtenerEstado';

/*Mantenimiento contactos*/
$route['mantenimiento/contacto'] = 'admin/mantenimiento/contacto/contacto';
$route['mantenimiento/agregarContacto'] = 'admin/mantenimiento/contacto/agregarContacto';
$route['mantenimiento/contacto/ObtenerContactoPorId'] = 'admin/mantenimiento/contacto/ObtenerContactoPorId';
$route['mantenimiento/contacto/EliminarContacto'] = 'admin/mantenimiento/contacto/EliminarContacto';
$route['mantenimiento/contacto/ActualizarContacto'] = 'admin/mantenimiento/contacto/ActualizarContacto';
$route['mantenimiento/contacto/InsertarContacto'] = 'admin/mantenimiento/contacto/InsertarContacto';

/*Mantenimiento eventos*/
$route['mantenimiento/evento'] = 'admin/evento/principal';
$route['mantenimiento/evento/obtenereventoporid'] = 'admin/evento/ObtenerEventoPorId';
$route['mantenimiento/insertarEvento'] = 'admin/evento/insertarevento';
$route['mantenimiento/evento/obtenerEvento'] = 'admin/evento/ObtenerEventos';
$route['mantenimiento/evento/eliminarevento'] = 'admin/evento/EliminarEvento';
$route['mantenimiento/evento/actualizarevento'] = 'admin/evento/ActualizarEvento';

/*Mantenimiento carousel*/
$route['mantenimiento/carousel'] = 'admin/mantenimiento/carousel/carousel';
$route['mantenimiento/carousel/insertarCarousel'] = 'admin/mantenimiento/carousel/insertarcarousel';

/*Mantenimiento Areas*/
$route['mantenimiento/areas'] = 'admin/mantenimiento/area/Principal';
$route['Mantenimientos/Areas/GetTable'] = 'admin/mantenimiento/area/AreaTable';
$route['Mantenimientos/Areas/Insertar'] = 'admin/mantenimiento/area/InsertarArea';
$route['Mantenimientos/Areas/Actualizar'] = 'admin/mantenimiento/area/ActualizaArea';
$route['Mantenimientos/Areas/Eliminar'] = 'admin/mantenimiento/area/EliminaArea';

/*Proyectos*/
$route['Proyecto/Creacion'] = 'admin/proyecto/Proyectos/Principal';
$route['Proyecto/Guardar'] = 'admin/proyecto/Proyectos/GuardarProyecto';
$route['Proyecto/AsignarIntegrante'] = 'admin/proyecto/Proyectos/AsignaIntegrante';

/*Perfil*/
$route['mantenimiento/perfil'] = 'admin/mantenimiento/perfil/principal';
$route['mantenimiento/perfil/agregarPerfil'] = 'admin/mantenimiento/perfil/AgregarPerfiles';
$route['mantenimiento/perfil/ObtenerPerfilPorId'] = 'admin/mantenimiento/perfil/ObtenerPerfilPorId';
$route['mantenimiento/perfil/ActualizarPerfil'] = 'admin/mantenimiento/perfil/ActualizarPerfil';
$route['Proyecto/asignar'] = 'admin/proyecto/asiganarjuez/asiganarjuez';
