<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array();
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.gmail.com';
$config['smtp_user'] = 'jordy.segura07@gmail.com';
$config['smtp_pass'] = 'PRsomeday0708';
$config['smtp_port'] = 587;
$config['smtp_crypto'] = 'tls';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";
$config['crlf'] = "\r\n";
