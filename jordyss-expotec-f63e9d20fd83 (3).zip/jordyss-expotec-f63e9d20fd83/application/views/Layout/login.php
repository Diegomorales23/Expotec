<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/animate.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/hover.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/main.css">
    <link rel="icon" href="<?php echo base_url() ?>content/favicon.ico">
    <title>Ingresar</title>
  </head>
  <body class="fondo-login" style="background-image: url(<?php echo base_url() . 'content/images/fondo-login.jpg' ?>);">
    <div class="container">
      <div class="row d-flex justify-content-center">
        <div class="col frmLogin">
          <div class="card">
              <div class="card-header">
                <a href="<?php echo base_url() ?>">
                  <img src="<?php echo base_url() ?>content/images/logo-cedes-color.png" alt="img-logo-don-bosco">
                </a>
              </div>
              <div class="card-body">
                <form method="post" action="<?php echo base_url('ingresar') ?>">
                  <div class="form-group form-group-icon input-icon ">
                    <i class="fa fa-envelope"></i>
                    <input name="correo" type="email" class="form-control " placeholder="Correo electrónico...">
                  </div>
                  <div class="form-group form-group-icon input-icon ">
                    <i class="fas fa-key"></i>
                    <input name="clave" type="password" class="form-control " placeholder="Contraseña...">
                  </div>
                  <center>
                    <button type="submit" class="btn text-uppercase btn-primero">
                      Enviar
                    </button>
                    <button type="submit" class="btn text-uppercase btn-primero">
                      Inicio
                    </button>
                  </center>
                </form>
                <div class="col padding">
                  <center>
                    <strong>
                      <a href="<?php echo base_url() ?>recuperarContrasenia">¿Olvidó su contraseña?</a>
                    </strong>
                  </center>
                </div>
                <div class="col">
                  <center>
                    <?php if ($this->session->flashdata('error')){ ?>
                      <div class"alerta-error">
                        <?php  echo '<p>' . $this->session->flashdata('error') . '</p>'; ?>
                      </div>
                    <?php } ?>
                  </center>
                </div>
              </div>
          </div>

        </div>
      </div>
    </div>
  </body>
</html>
