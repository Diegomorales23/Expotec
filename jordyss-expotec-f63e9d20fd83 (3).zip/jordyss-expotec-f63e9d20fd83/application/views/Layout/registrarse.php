<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/animate.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/hover.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/main.css">
    <link rel="icon" href="<?php echo base_url() ?>content/favicon.ico">
    <title>Registrese</title>
  </head>
  <body class="fondo-login" style="background-image: url(<?php echo base_url() . 'content/images/fondo-login.jpg' ?>);">
    <div class="container">
      <div class="row d-flex justify-content-center">
        <div class="col frmLogin">
          <div class="card">
              <div class="card-header">
                <a href="<?php echo base_url() ?>">
                  <img src="<?php echo base_url() ?>content/images/logo-cedes-color.png" alt="img-logo-don-bosco">
                </a>
              </div>
              <div class="card-body">
                <form method="post">
                  <div class="form-group form-group-icon input-icon ">
                    <i class="fa fa-envelope"></i>
                    <input required type="email" class="form-control " placeholder="Correo electrónico..." required="">
                  </div>
                  <div class="form-group form-group-icon input-icon ">
                    <i class="fas fa-key"></i>
                    <input required type="password" class="form-control " placeholder="Contraseña..." required="">
                  </div>
                  <center>
                    <button type="submit" class="btn text-uppercase btn-primero">
                      Enviar
                    </button>
                    <button type="submit" class="btn text-uppercase btn-primero">
                      Inicio
                    </button>
                  </center>
                </form>
                <div class="col padding">
                  <center>
                    <strong>
                      <a href="<?php echo base_url() ?>recuperarContrasenia">¿Olvidó su contraseña?</a>
                    </strong>
                  </center>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
