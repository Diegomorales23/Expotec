<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Expotec</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/animate.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/hover.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>content/css/main.css">
    <link rel="icon" href="<?php echo base_url() ?>content/favicon.ico">
  </head>
  <body>
    <div class="row header-1 " style="background:#e7e7e7;">
      <div class="col">
        <a href="<?php echo base_url(); ?>">
            <img class="wow zoomIn" data-wow-offset="10" data-wow-duration="1.7s" src="content/images/logo-cedes-color.png" alt="img-logo-cedes-no-color">
        </a>
      </div>
      <div class="col text-right icons">
        <a href="#"><img src="content/images/icons/facebook-color-redondo.svg" alt="img-facebook"></a>
        <a href="#"><img src="content/images/icons/twitter-color-redondo.svg" alt="img-twitter"></a>
        <a href="#"><img src="content/images/icons/youtube-color-redondo.svg" alt="img-instagram"></a>
        <div class="login">
          <a href="<?php echo base_url() ?>login">
            <i class="fas fa-sign-in-alt"></i>
            <strong>Ingresar</strong>
          </a>
        </div>
      </div>
    </div>

    <div class="row">
      <img src="content/images/fondo-principal.jpg" class="img-fluid" alt="img-principal">
    </div>
    <div class="row">
      <div class="col menu">

        <div class="col">
          <nav>
            <strong>
            <ul>
              <li><a href="#"> Inicio</a></li>
              <li><a href="#">Acerca de</a></li>
              <li><a href="#">Galeria</a></li>
              <li><a href="#">Eventos</a></li>
              <li><a href="#">Buscador proyectos</a></li>
            </ul>
          </strong>
          </nav>
        </div>
      </div>
    </div>
  <div class="container-fluid">
