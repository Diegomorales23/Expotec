</div><!--FINALIZA CONTAINER-FLUID -->
<footer>
  <div class="row dashboard-footer">
    <div class="dashboard-footer-1">
    </div>
    <div class="dashboard-footer-2">
    </div>
  </div>
  <div class="row">
    <div class="col-sm-12 col-md-6 footer-1 padding">
      <div class="padding">
        <img src="content/images/logo-cedes-color.png" alt="img-don-bosco-logo-color">
      </div>
      <div class="col barra">
        <div class="col">
            <i class="fa fa-envelope "></i>
          <strong><label for="">Correo:</label></strong>
          <label for="">info @cedesdonbosco.ed.cr</label>
        </div>
        <div class="col">
            <i class="fa fa-phone fa-rotate-90 "></i>
          <strong><label for="">	Teléfono:	</label></strong>
          <label for="">(506) 2275-0031</label>
        </div>
        <div class="col">
            <i class="fa fa-fax "></i>
            <strong><label for="">	Fax:</label></strong>
            <label for="">(506) 2275-6714</label>
        </div>
        <div class="col">
            <i class="fa fa-calendar "></i>
          <strong><label for="">Horario:</label></strong>
          <label for="">07:00 am a 12:30 pm y de 01:30 pm a 04:30 pm</label>
        </div>
      </div>
    </div>
    <div class="col-sm-12 col-md-6 footer-2 padding">
      <div class="col padding">
        <h2>Contáctenos</h2>
      </div>
        <div class="col">
              <form method="post" class="frmContacto" >
                <div class="form-group form-group-icon input-icon icon-color-footer">
                  <i class="fa fa-user "></i>
                  <input required type="text" class="form-control border-segundo" placeholder="Nombre..." required="">
                </div>
                <div class="form-group form-group-icon input-icon icon-color-footer">
                  <i class="fa fa-envelope "></i>
                  <input required type="email" class="form-control border-segundo" placeholder="Correo electrónico..." required="">
                </div>
                <div class="form-group form-group-icon input-icon icon-color-footer">
                  <i class="fa fa-comments "></i>
                  <textarea required class="form-control border-segundo" placeholder="Mensaje..." rows="6"></textarea>
                </div>
                  <button type="submit" class="btn float-right text-uppercase btn-primero">
                    Enviar
                  </button>
              </form>
        </div>
    </div>
  </div>
  <div class="row padding footer-3" style="background:#e7e7e7;">
    <div class="col text-left">
      <strong><label> © Proyecto estudiantil Universidad fidélitas 2019 </label></strong>
    </div>
    <div class="col text-right">
      <a href="#"><img class="wow zoomIn" data-wow-offset="10" data-wow-duration="1.7s" src="content/images/icons/facebook-color-redondo.svg" alt="img-facebook"></a>
      <a href="#"><img class="wow zoomIn" data-wow-offset="10" data-wow-duration="1.7s" src="content/images/icons/twitter-color-redondo.svg" alt="img-twitter"></a>
      <a href="#"><img  class="wow zoomIn" data-wow-offset="10" data-wow-duration="1.7s" src="content/images/icons/youtube-color-redondo.svg" alt="img-instagram"></a>
    </div>
  </div>
</footer>

<script src="content/js/jquery/jquery-3.4.1.min.js"></script>
<script src="content/js/bootstrap/bootstrap.min.js"></script>
<script src="content/css/fontawesome/js/fontawesome.min.js"></script>
<script src="content/js/wow.min.js"></script>
<script src="content/js/script/Utilidades.js"></script>
</body>
</html>
