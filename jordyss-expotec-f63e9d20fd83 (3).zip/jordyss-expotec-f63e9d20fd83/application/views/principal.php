<?php
  defined('BASEPATH') OR exit('No direct script access allowed');
  Include('Layout/header.php');
?>
<div class="row">
  <h2>Main</h2>
</div>

<?php
  Include('Layout/footer.php');
?>
