
<main class="main-container">
        <!-- Page content-->
        <section>
          <div class="contaner-fluid">
            <div class="row">
              <div class="col-xs-12 col-md-12">
                <div class="card">
                    <div class="card-heading">
                        <div class="card-title text-center"><h2>Agregar Contacto</h2><hr></div>
                    </div>
                    <div class="card-body pv" id='idDatosInsertar'>
                      <form>
                        <div class="row">
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="text" class="form-control" name="nombre" value="" placeholder="Nombre...">
                          </div>
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="mail" class="form-control" name="correo" value="" placeholder="Correo electrónico...">
                          </div>
                        </div>
                      </form>
                    </div>
                </div>
                <div class="card-footer">
                  <div class="text-right">
                    <a href="#" class="btn btn-secondary " id="btnAgregar">Agregar</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
</main>
