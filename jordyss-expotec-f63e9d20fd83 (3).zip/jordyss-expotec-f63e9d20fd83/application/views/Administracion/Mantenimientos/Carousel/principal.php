<main class="main-container">
        <!-- Page content-->
      <section>
        <div class="contaner-fluid">
        <div class="row">
          <?php echo '<form method="post" style="width:100%;" action="' . base_url() . 'mantenimiento/carousel/insertarCarousel" enctype="multipart/form-data">';  ?>
            <div class="col-xs-12 col-md-12">
              <div class="card">
                <div class="card-heading">
                    <div class="card-title text-center"><h2>Carousel slider</h2><hr></div>
                </div>
                <div class="card-body pv" id='idDatosInsertar'>
                      <div class="row">
                        <div class="col-xs-12 col-md-12 form-group">
                          <label for="" class="label-form">Título:</label>
                          <input type="text" class="form-control" name="nombre" value="">
                        </div>
                        <div class="col-xs-12 col-md-12 form-group">
                          <label for="" class="label-form">Imagen:</label>
                          <?php echo "<input type='file' class='form-control' name='imagen' size='20' />"; ?>
                        </div>
                        <div class="col-xs-12 col-md-12 form-group">
                          <label for="" class="label-form">Automatico:</label>
                          <input type="checkbox" name="esAutomatico" value="" checked>
                        </div>
                      </div>
                </div>
                <div class="card-footer">
                  <div class="text-right">
                    <?php echo "<input type='submit' class='btn btn-secondary' name='submit' value='Agregar' /> ";?>
                  </div>
                </div>
              </div>
            </div>
          <?php echo "</form>"?>
        </div>
        </div>
      </section>
      <section>
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="multiple-items">
                <ul>
                  <?php if(!empty($carousel)): ?>
                    <?php foreach($carousel as $item): ?>
                      <li class="item">
                        <img style="width: 200px;height: 200px;" src="<?php base_url() ?>..<?= $item->urlImagen?>" alt="img-<?= $item->idSliderCarousel?>">
                        <label for=""><?= $item->nombre?></label>
                      </li>
                    <?php endforeach ;?>
                  <?php endif;?>
                </ul>

              </div>
            </div>
          </div>
        </div>
      </section>
</main>
