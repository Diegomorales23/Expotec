
<main class="main-container">
        <!-- Page content-->
        <section>
          <div class="contaner-fluid">
            <div class="row">
              <div class="col-xs-12 col-md-12">
                  <div class="card">
                      <div class="card-heading">
                          <div class="card-title text-center"><h2>Administración de perfil</h2><hr></div>
                      </div>
                      <div class="card-body pv">
                          <div class="">
                              <table id="id_table" class="display display table responsive nowrap" width="100%">
                                  <thead>
                                      <tr>
                                          <th id="idRow">Id</th>
                                          <th>Nombre</th>
                                          <th>Descripción</th>
                                          <th>Estado</th>
                                          <th>Acción</th>

                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php if(!empty($perfiles)): ?>
                                      <?php foreach($perfiles as $perfil): ?>
                                      <tr>
                                          <th><?= $perfil->idPerfil?></th>
                                          <th><?= $perfil->nombre?></th>
                                          <th><?= $perfil->descripcion?></th>
                                          <th>
                                            <?php if ($perfil->idEstado == 1): ?>
                                              <p>Activo</p>
                                            <?php else: ?>
                                              <p>Desactivado</p>
                                            <?php endif; ?>
                                          </th>
                                          <th>
                                            <a class="table-btn" id="idEditar" href="#" data-toggle="modal" data-target="#idModalEdit" data-click=1><i class="fas fa-edit" title="Editar usuario"></i></a>
                                            <a class="table-btn" id="idEliminar" href="#"><i class="fas fa-trash-alt " title="Eliminar usuario"></i></a>
                                            <a id="idDetalle" href="#" class="table-btn" data-toggle="modal" data-target="#idModal" data-click=0><i class="fas fa-search" title="Detalle de usuario"></i></a>
                                          </th>
                                      </tr>
                                      <?php endforeach ;?>
                                    <?php endif;?>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                      <div class="card-footer">
                        <div class="text-right">
                          <a href="<?php base_url() ?>perfil/agregarPerfil" class="btn btn-secondary ">Nuevo Perfil</a>

                        </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </section>
</main>

<div class="modal" id="idModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detalle Perfil</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="idDatosDetallePerfil">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="idModalEdit" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Editar Perfil</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="idDatosEditarPerfil">
        <form>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="btnEditar">Editar</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
