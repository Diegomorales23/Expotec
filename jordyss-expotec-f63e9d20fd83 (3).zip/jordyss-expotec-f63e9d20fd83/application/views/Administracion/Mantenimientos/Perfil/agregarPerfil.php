<main class="main-container">
        <!-- Page content-->
        <section>
          <div class="contaner-fluid">
            <div class="row">
              <div class="col-xs-12 col-md-12">
                <div class="card">
                    <div class="card-heading">
                        <div class="card-title text-center"><h2>Agregar Perfil</h2><hr></div>
                    </div>
                    <div class="card-body pv" id='idDatosInsertar'>
                      <form>
                        <div class="row">
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="text" class="form-control" name="nombre" value="" placeholder="Nombre Perfil...">
                          </div>
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="text" class="form-control" name="descripcion" value="" placeholder="Descripción...">
                          </div>
                          <div class="col-xs-12 col-md-6 form-group">
                            <select class="form-control" name="idEstado" id="idEstado"></select>
                          </div>
                        </div>
                      </form>
                    </div>
                </div>
                <div class="card-footer">
                  <div class="text-right">
                    <a href="#" class="btn btn-secondary " id="btnAgregar">Agregar</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
</main>


<script type="text/javascript">
window.addEventListener("load",function(){
    cargarEstado('#idEstado',1);
},false);
</script>
