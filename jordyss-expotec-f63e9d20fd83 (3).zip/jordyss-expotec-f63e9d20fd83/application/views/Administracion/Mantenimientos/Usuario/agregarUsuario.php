
<main class="main-container">
        <!-- Page content-->
        <section>
          <div class="contaner-fluid">
            <div class="row">
              <div class="col-xs-12 col-md-12">
                <div class="card">
                    <div class="card-heading">
                        <div class="card-title text-center"><h2>Agregar Usuario</h2><hr></div>
                    </div>
                    <div class="card-body pv" id='idDatosInsertar'>
                      <form>
                        <div class="row">
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="text" class="form-control" name="nombre" value="" placeholder="Nombre...">
                          </div>
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="text" class="form-control" name="apellido1" value="" placeholder="Apellidos...">
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-xs-12 col-md-6 form-group">
                            <input type="mail" class="form-control" name="correo" value="" placeholder="Correo electrónico...">
                          </div>
                          <div class="col-xs-12 col-md-6">
                            <input type="password" class="form-control" name="clave" value="" placeholder="Clave...">
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-xs-12 col-md-6 form-group">
                            <select class="form-control" name="idEstado" id="idEstado"></select>
                          </div>
                          <div class="col-xs-12 col-md-6 form-group">
                            <select class="form-control" name="idPerfil" id="idPerfil"></select>
                          </div>
                        </div>
                      </form>
                    </div>
                </div>
                <div class="card-footer">
                  <div class="text-right">
                    <a href="#" class="btn btn-secondary " id="btnAgregar">Agregar</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
</main>


<script type="text/javascript">
window.addEventListener("load",function(){
    cargarPerfil('#idPerfil',1);
    cargarEstado('#idEstado',1);
},false);
</script>
