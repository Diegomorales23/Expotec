<!-- <script src="
<
	?php echo base_url() ?>/js/Mantenimiento_Areas.js"></script> -->

    <main class="main-container">
	<div class="contaner">
		<br>
		<p style="font-family:monserrat-font;color:#bb8d09;font-size:40px;margin-left:30px;"> Areas</p>
		<hr style="color:#bb8d09">
		<div class="row">
			<div class="col-md-11" style="background-color:white;padding-left:10px;margin-left:30px;" >
				<form>
					
					<div class="row" style="padding-top: 35px;" id="DatosArea">
						<input name="idArea" id="idArea" type="text" style="font-family:monserrat-font;visibility:hidden" class="form-control" aria-describedby="Nombre" placeholder="Nombre" id="TextArea">	
						<div class="col-md-4">
							<div class="form-group" >
								<label style="font-family:monserrat-font;">Nombre: </label>
								<input name="txtNombreArea" id="txtNombreArea" type="text" style="font-family:monserrat-font;" class="form-control" aria-describedby="Nombre" placeholder="Nombre" id="TextArea">
								
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group" >
								<br>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group" >
								<br>
								<a href="#"  id="btnGuardarArea" class="btn btn-primary pull-right" style="margin_left:10px;margin-top:10px;"><i class="fas fa-save"> Guargar</i></a>
							</div>
						</div>
						<div class="col-md-3" style="margin-top:10px;">
							<div class="form-group">
								<label for="exampleFormControlSelect1" style="font-family:monserrat-font;">Coordinador</label>
								<select name="ddCoordinador" id="ddCoordinador" class="form-control" style="font-family:monserrat-font;" id="CbCoordinador">
									<option value = ''>Elija un Coordinador</option>
									<?php for( $i=0; $i<count($coordinadores); $i++ ) { ?>

									<option value="<?php echo $coordinadores[0]->id  ?>"> <?php echo $coordinadores[0]->Nombre  ?> </option>
									<?php }?>
								</select>
							</div>
						</div>
						
						<div class="col-md-7"  style="margin-top:10px;">
							<div class="form-group">
								<label for="exampleFormControlTextarea1" style="font-family:monserrat-font;" >Descripción</label>
								<textarea name="txtDescripcion" id="txtDescripcion" class="form-control" style="font-family:monserrat-font;"  rows="1" id="DescArea"></textarea>
							</div>
						</div>
					</div>
					<div class="row" style="padding-bottom: 35px">
						<div class="col-md-12">
							<div class="table-responsive">
								<table id="tbl-areas" class="table table-bordered table-striped table-hover">
									<thead>
										<tr>
											<th scope="col">Id</th>
											<th scope="col">Nombre</th>
											<th scope="col">Descripción</th>
											<th scope="col">NombreCoordinador</th>
											<th scope="col">IdCoordinador</th>
											<th scope="col"></th>
											<th scope="col"></th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
						<div>
					</div>
				</form>
			</div>
		</div>
	</div>
</main>
<script type="text/javascript">

var baseurl="<?php echo base_url(); ?>";

</script>