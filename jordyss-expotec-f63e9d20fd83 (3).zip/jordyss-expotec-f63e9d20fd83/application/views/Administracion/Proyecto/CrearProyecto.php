<!-- <script src="
<
	?php echo base_url() ?>/js/Mantenimiento_Areas.js"></script> -->
    <main class="main-container">
	<div class="contaner-fluid">
		<br>
		<p style="font-family:monserrat-font;color:#bb8d09;font-size:40px;margin-left:30px;"> Crear Proyecto</p>
		<hr style="color:#bb8d09">
		<div class="row">
			<div class="col-md-11" style="background-color:white;padding-left:10px;margin-left:30px;" >
				<form>
					<div style="padding-top: 35px;padding-left:30px;">
					
						<ul class="nav nav-pills mb-3" id="myTab" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Información General</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Registro de Integrantes</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="messages-tab" data-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false">Archivos Adjuntos</a>
							</li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab">
								<div class="row" style="padding-top: 35px;padding-left:30px;padding-botton: 35px;margin-botton:50px">
									<div class="col-md-4">
										<div class="form-group" >
											<label style="font-family:monserrat-font;">Nombre Proyecto: </label>
											<input name="txtNombreProyecto" id="txtNombreProyecto" type="text" style="font-family:monserrat-font;" class="form-control" aria-describedby="Nombre" placeholder="Nombre" id="TextArea">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="exampleFormControlSelect1" style="font-family:monserrat-font;">Area: </label>
											<select name="ddArea" id="ddArea" class="form-control" style="font-family:monserrat-font;" id="cdArea">
												<option value = ''>Elija un Area</option>
												<?php for( $i=0; $i<count($area); $i++ ) { ?>
													<option value="<?php echo $area[0]->idArea  ?>"> <?php echo $area[0]->Nombre  ?> </option>
												<?php }?>
											</select>
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label  style="font-family:monserrat-font;" >Grado: </label>
											<input name="txtGrado" id="txtGrado" class="form-control" style="font-family:monserrat-font;" type="number"  id="Grado"></input>
										</div>
									</div>
									<div class="col-md-7"  style="margin-top:10px;margin-botton:30px;">
										<div class="form-group">
											<label for="exampleFormControlTextarea1" style="font-family:monserrat-font;" >Descripción: </label>
											<textarea name="txtDescripcion" id="txtDescripcion" class="form-control" style="font-family:monserrat-font;"  rows="1"></textarea>
										</div>
									</div>
									<div class="col-md-2"  style="margin-top:10px;margin-botton:30px;">
										<div class="form-group">
											<br>
											
											<a href="#"  id="btnGuardarProyecto" class="btn btn-primary pull-right" style="margin_left:10px;margin-top:5px;"><i class="fas fa-save"> Guargar</i></a>
										</div>
									</div>
									<br>
									<br>
									<div  class="col-md-7"  style="margin-top:10px;margin-botton:30px;"><br>
									<br></div>
								</div>						
							</div>
							<div class="tab-pane" id="profile" role="tabpanel" aria-labelledby="profile-tab" with="50%" higt="40%">
								<div class="row" style="padding-top: 35px;padding-left: 35px; ">
								<div class="col-md-7">
										<div class="form-group">
											<label for="exampleFormControlSelect1" style="font-family:monserrat-font;">Proyectos: </label>
											<select name="ddProyecto" id="ddProyecto" class="form-control" style="font-family:monserrat-font;">
												<option value = ''>Elija un Proyecto</option>
												<?php for( $i=0; $i<count($Proyecto); $i++ ) { ?>
													<option value="<?php echo $Proyecto[0]->id  ?>"> <?php echo $Proyecto[0]->Nombre  ?> </option>
												<?php }?>
											</select>
										</div>
									</div>
									<div class="col-md-7"  style="margin-top:30px;margin-botton:30px;">
										<div class="table-responsive">
											<table id="tbl-usuarios" class="table table-bordered table-striped table-hover">
												<thead>
													<tr>
														<th scope="col">Id</th>
														<th scope="col">Nombre</th>
														<th scope="col"></th>
													</tr>
												</thead>
												<tbody>
												</tbody>
											</table>
										</div>
									</div>
								</div>	
							</div>
							<div class="tab-pane" id="messages" role="tabpanel" aria-labelledby="messages-tab" with="50%" higt="40%">
								<div class="row" style="padding-top: 35px;">
									<div class="col-md-7"  style="margin-top:10px;margin-botton:30px;">
										<label for="" class="label-form">Imagen:</label>
                            			<input type='file' class='form-control' name='imagen' size='20'/>
									</div>
									<div class="col-md-7"  style="margin-top:5px;margin-botton:30px;">
										<div class="table-responsive">
											<table id="tbl-areas" class="table table-bordered table-striped table-hover">
												<thead>
													<tr>
														<th scope="col">Imagen</th>
														<th scope="col"></th>
													</tr>
												</thead>
												<tbody>
												</tbody>
											</table>
										</div>
									</div>
								<div>
							</div>
						</div>	
					</div>
				</form>
			</div>
		</div>
	</div>
</main>
<script type="text/javascript">
var baseurl="<?php echo base_url(); ?>";
</script>

