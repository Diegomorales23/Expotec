<aside class="sidebar-container">
<div class="sidebar-header">
        <div class="pull-right pt-lg text-muted hidden"><em class="ion-close-round"></em></div>
            <div class="box-icon animated zoomIn">
                <a href="<?php base_url(); ?>../Administracion/Principal">
                    <img src="<?php echo base_url() ?>/Content/images/logo-expotec-2.png" alt="img-expo-logo" class=" img-responsive">
                </a>
            </div>
        <div class="info"><h4 class="text-center">Bienvenido</h4></div>
        <div class="info">
          <h6 class="text-center text-color-tercero">
            <?php
              if (isset($nombreUsuario)){
                echo $nombreUsuario;
              }
             ?>
        </h6></div>
    </div>

<div class="sidebar-content">
  <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-inverse">

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item animated fadeInLeft icon-option">

        </li>
        <li class="nav-item animated fadeInLeft icon-option">
          <a class="nav-link" href="<?php base_url() ?>../mantenimiento/evento">Eventos</a>
        </li>
        <li class="nav-item animated fadeInLeft icon-option">
          <a class="nav-link" href="<?php base_url() ?>../Proyecto/Creacion">Proyectos</a>
        </li>
        <li class="nav-item dropdown animated fadeInLeft icon-option">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Mantenimientos
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="nav-link" href="<?php base_url() ?>../mantenimiento/carousel">Carousel Slider <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="<?php base_url() ?>../mantenimiento/contacto">Contacto <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="<?php base_url() ?>../mantenimiento/usuario">Usuarios <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="<?php base_url() ?>../mantenimiento/perfil">Perfil <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="<?php base_url() ?>../mantenimiento/areas">Areas <span class="sr-only">(current)</span></a>

          </div>
        </li>
      </ul>

    </div>
  </nav>
    </div>
</aside>
