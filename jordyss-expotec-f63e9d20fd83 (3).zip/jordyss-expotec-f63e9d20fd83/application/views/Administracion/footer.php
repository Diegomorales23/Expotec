


<script src="<?php base_url(); ?>../content/js/jquery/jquery-3.4.1.min.js"></script>
<script src="<?php base_url(); ?>../content/js/bootstrap/bootstrap.min.js"></script>
<script src="<?php base_url(); ?>../content/css/fontawesome/js/fontawesome.min.js"></script>
<script src="<?php base_url(); ?>../content/js/slick/slick.js"></script>

<script src="<?php base_url(); ?>../content/js/wow.min.js"></script>
<script src="<?php base_url(); ?>../content/sweetalert/sweetalert.min.js"></script>
<script src="<?php base_url(); ?>../content/datatable/js/jquery.dataTables.js"></script>
<script src="<?php base_url(); ?>../content/datatable/js/dataTables.responsive.min.js"></script>

<script src="<?php base_url(); ?>../content/js/script/Utilidades.js"></script>

<? if ($script != '') : ?>
  <script src="<?php base_url(); ?>../script/<?=$script;?>"></script>
<? endif;?>

</body>
</html>
