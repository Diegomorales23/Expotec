<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <title>Expotec</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/css/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/all.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/css/fontawesome/css/fontawesome.min.css">

  <link rel="stylesheet" href="<?php echo base_url() ?>content/datatable/css/jquery.dataTables.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/datatable/css/responsive.dataTables.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/datatable/css/buttons.dataTables.min.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/datatable/css/select.dataTables.min.css">

  <link rel="stylesheet" href="<?php echo base_url() ?>content/css/animate.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/css/hover.css">
  <link rel="stylesheet" href="<?php echo base_url() ?>content/css/main.css">
  <link rel="icon" href="<?php echo base_url() ?>content/favicon.ico">
</head>
  <body>
<div class="header-menu">
  <div class="">
    <a href="#" class="navbar-toggler" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars">
      </i>
    </a>
  </div>
  <div class="menu-button">
    <div class="menu-option">
       <ul class="">
           <li class="animated zoomIn"><a><i class="fas fa-question "></i></a></li>
           <li class="animated zoomIn"><a title="Editar datos de usuario" href="<?php echo base_url() ?>Administracion/EditarDatosUsuario"><i class="fas fa-cog"></i></a></li>
           <li class="animated zoomIn"><a href="<?php echo base_url() ?>salir"><i class="fas fa-power-off"></i></a></li>
       </ul>
    </div>
  </div>
</div>
