
<main class="main-container">
        <!-- Page content-->
        <section>
          <div class="contaner-fluid">
            <div class="row">
              <div class="col-xs-12 col-md-12">
                <?php echo '<form method="post" action="' . base_url() . 'mantenimiento/insertarEvento" enctype="multipart/form-data">';  ?>
                <div class="card">
                  <div class="card-heading">
                      <div class="card-title text-center"><h2>Eventos</h2><hr></div>
                  </div>
                    <div class="card-body pv" id='idDatosInsertar'>
                        <div class="row">

                          <div class="col-xs-12 col-md-4 form-group">
                            <label for="" class="label-form">Título:</label>
                            <input type="text" class="form-control" name="titulo" value="">
                          </div>
                          <div class="col-xs-12 col-md-4 form-group">
                            <label for="" class="label-form">Horario:</label>
                            <input type="text" class="form-control" name="horario" value="">
                          </div>
                          <div class="col-xs-12 col-md-4 form-group">
                            <label for="" class="label-form">Lugar:</label>
                            <input type="text" class="form-control" name="lugar" value="" placeholder="">
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-xs-12 col-md-4 form-group">
                            <label for="" class="label-form">Cupos disponibles:</label>
                            <input type="number" name="cupo" class="form-control" value="0">
                          </div>
                          <div class="col-xs-12 col-md-4 form-group">
                            <label for="" class="label-form">Estado:</label>
                            <select class="form-control" name="estado">
                              <option value="1">Activo</option>
                              <option value="0">Inactivo</option>
                            </select>
                          </div>
                          <div class="col-xs-12 col-md-4 form-group">
                            <label for="" class="label-form">Imagen:</label>
                            <?php echo "<input type='file' class='form-control' name='imagen' size='20' />"; ?>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-xs-12 col-md-12 form-group">
                            <label for="">Descripción:</label>
                            <textarea name="descripcion" id="descripcion" class="form-control" rows="2" cols="10"></textarea>
                          </div>
                        </div>
                    </div>

                </div>
                <div class="card-footer">
                  <div class="text-right">
                    <?php echo "<input type='submit' class='btn btn-secondary' name='submit' value='Agregar' /> ";?>
                  </div>
                </div>
                <?php echo "</form>"?>
              </div>

              <div class="col-xs-12 col-md-12">
                  <div class="card">
                      <div class="card-body pv">
                          <div class="">
                              <table id="id_table" class="display display table responsive nowrap" width="100%">
                                  <thead>
                                      <tr>
                                          <th>Id</th>
                                          <th>Nombre</th>
                                          <th>Descripción</th>
                                          <th>Url</th>
                                          <th>Acciones</th>
                                      </tr>
                                  </thead>
                                  <tbody>
                                    <?php if(!empty($eventos)): ?>
                                      <?php foreach($eventos as $evento): ?>
                                      <tr>
                                          <th><?= $evento->idEvento?></th>
                                          <th><?= $evento->titulo?></th>
                                          <th><?= $evento->descripcion?></th>
                                          <th><?= $evento->imagen?></th>
                                          <th>
                                            <a class="table-btn" id="idEditar" href="#" data-toggle="modal" data-target="#idModalEdit" data-click=1><i class="fas fa-edit" title="Editar usuario"></i></a>
                                            <a class="table-btn" id="idEliminar" href="#"><i class="fas fa-trash-alt " title="Eliminar usuario"></i></a>
                                            <a id="idDetalle" href="#" class="table-btn" data-toggle="modal" data-target="#idModal" data-click=0><i class="fas fa-search" title="Detalle de usuario"></i></a>
                                          </th>
                                      </tr>
                                      <?php endforeach ;?>
                                    <?php endif;?>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>


          <div class="modal" id="idModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Detalle Evento</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="idDatosDetalleEvento">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
              </div>
            </div>
          </div>

          <div class="modal" id="idModalEdit" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Editar Usuario</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" id="idDatosEditarUsuario">
                  <form>

                  </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" id="btnEditar">Editar</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
              </div>
            </div>
          </div>


        </section>
</main>
