<main class="main-container">
        <!-- Page content-->
        <section>
          <div class="contaner-fluid">
            <div class="row">
              <?php echo '<form method="post" action="' . base_url() . 'Administracion/actualizarusuario" enctype="multipart/form-data">';  ?>
              <div class="col-xs-12 col-md-12">
                <div class="card">
                  <div class="card-heading">
                      <div class="card-title text-center"><h2>Editar datos</h2><hr></div>
                  </div>
                    <div class="card-body pv" id='idDatosInsertar'>
                        <div class="row">
                          <?php if(!empty($usuario)): ?>
                            <?php foreach($usuario as $item): ?>
                            <div class="col-12"><strong><label>Nombre:</label></strong><input class="form-control" type="text" name="nombre" value="<?= $item->nombre?>"></div>
                            <div class="col-12"><strong><label>Apellidos:</label></strong><input class="form-control" type="text" name="apellidos" value="<?= $item->apellidos?>"></div>
                            <div class="col-12"><strong><label>Contraseña:</label></strong><input class="form-control" type="password" name="clave" value="<?= $item->clave?>"></div>
                            <div class="col-12"><strong><label>Nueva Contraseña:</label></strong><input class="form-control" type="password" name="Nuevaclave" value=""></div>
                            <?php endforeach ;?>
                          <?php endif;?>
                        </div>
                      </div>
                      <div class="card-footer">
                        <div class="text-right">
                          <?php echo "<input type='submit' class='btn btn-secondary' name='submit' value='Actualizar' /> ";?>
                        </div>
                      </div>
                      </div>
                    </div>
                    <?php echo "</form>"?>
              </div>
              </div>
            </section>
</main>
