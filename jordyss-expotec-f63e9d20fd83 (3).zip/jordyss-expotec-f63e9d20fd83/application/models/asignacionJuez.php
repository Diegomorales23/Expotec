<?php

require_once APPPATH . 'core/Mantenimientos.php';

class asignacionJuez extends CI_Model
{

  public $nombreTabla = 'cdb_juez_x_proyecto';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }

  
  public function ObtenerAsignar()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerAsignarPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,'id',$valorFiltro);
  }

  public function InsertarAsignar($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarAsignar($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,'id',$valorFiltro);
  }

  public function EliminarAsignar($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,'id',$valorFiltro);
  }
}


?>