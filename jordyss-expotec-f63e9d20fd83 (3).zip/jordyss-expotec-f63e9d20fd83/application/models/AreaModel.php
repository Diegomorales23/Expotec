<?php

require_once APPPATH . 'core/Mantenimientos.php';

class AreaModel extends CI_Model
{

   public $estadoActivo = 1;
   public $nombreTabla = 'cdb_usuario';

   public function __construct() {
      parent::__construct();

      $this->load->helper('security');
      $this->load->database();
   }

   public function getCoordinadores (){
      $resultado = $this->db->query('call cdb_Coordinador_Seleccionar');
      return $resultado->result();
   }
   
   public function getAreas(){
      $resultado = $this->db->query("call cdb_Area_Seleccionar");
      return $resultado->result();
   }

   public function insertAreas($Datos){
      //$resultado = $this->db->insert('cdb_area',$Datos);
      $resultado =  $this->db->query("call cdb_Area_Insertar(?,?,?)",$Datos);
      if($resultado = 1){
         return true;

      }else{
         return false;
      }
   }
   public function actualizarArea($Datos){
      return $this->db->query("call cdb_Area_Actualizar(?,?,?,?)",$Datos);
   }
   public function EliminaAreas($Datos){
     return $this->db->query("call cdb_Area_Eliminar(?)",$Datos);
   }
}
?>