<?php

require_once APPPATH . 'core/Mantenimientos.php';

class BitacoraModel extends CI_Model
{

  public $nombreTabla = 'cdb_bitacora';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }



  public function InsertarBitacora($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }
}


?>
