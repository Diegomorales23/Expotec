<?php

require_once APPPATH . 'core/Mantenimientos.php';

class EventoModel extends CI_Model
{

  public $estadoActivo = 1;
  public $nombreTabla = 'cdb_evento';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }

  /********** LOGIN DE USUARIOS **********
  /*
    Registra el usuario en el formulario, el usuario debe recibir un correo indicandole que
    su registro debe ser aprobado para poder ingresar al sistema.
  */
  /**********                    **********/

  public function ObtenerEventos()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerEventoPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,'idEvento',$valorFiltro);
  }

  public function InsertarEvento($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarEvento($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,'idEvento',$valorFiltro);
  }

  public function EliminarEvento($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,'idEvento',$valorFiltro);
  }
}

?>
