<?php

require_once APPPATH . 'core/Mantenimientos.php';

class Estado extends CI_Model
{


  public $nombreTabla = 'cdb_estado';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }


  public function ObtenerEstado()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerEstadoPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,'idEstado',$valorFiltro);
  }

  public function InsertarEstado($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarEstado($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,'idEstado',$valorFiltro);
  }

  public function EliminarEstado($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,'idEstado',$valorFiltro);
  }
}

?>
