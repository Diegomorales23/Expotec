<?php

require_once APPPATH . 'core/Mantenimientos.php';

class CarouselModel extends CI_Model
{
  public $nombreTabla = 'cdb_slidercarousel';
  public $nombreCampo = 'idSliderCarousel';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }


  public function ObtenerCarousel()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerCarouselPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,$nombreCampo,$valorFiltro);
  }

  public function InsertarCarousel($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarCarousel($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,$nombreCampo,$valorFiltro);
  }

  public function EliminarCarousel($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,$nombreCampo,$valorFiltro);
  }
}

?>
