<?php

require_once APPPATH . 'core/Mantenimientos.php';

class UsuarioModel extends CI_Model
{

  public $estadoActivo = 1;
  public $nombreTabla = 'cdb_usuario';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }

  /********** REGISTRO DE USUARIOS **********
  /*
    Registra el usuario en el formulario, el usuario debe recibir un correo indicandole que
    su registro debe ser aprobado para poder ingresar al sistema.
  */
  /**********                    **********/
  public function RegistrarUsuario($pNombre, $pApellido1, $pApellido2, $pCorreo, $pClave){

    $data = array(
          'nombre' => $pNombre,
          'description' => $this->input->post('description')
      );
      return $this->db->insert( 'usuario', $data);

    $query = $this->db->query("INSERT INTO usuario (username, email, password) VALUES ('$name', '$email', md5('$password'))");
  }

  /********** LOGIN DE USUARIOS **********
  /*
    Registra el usuario en el formulario, el usuario debe recibir un correo indicandole que
    su registro debe ser aprobado para poder ingresar al sistema.
  */
  /**********                    **********/
  public function VerificarUsuario()
  {
    $username = $this->input->post('correo');
    $clave = do_hash($this->input->post('clave'),'md5');
    $this->db->where('correo',$username);
    $this->db->where('clave',$clave);
    $this->db->where('idEstado',$this->estadoActivo);

    $this->db->from('cdb_usuario',1);
    $query = $this->db->get();

    if($query->num_rows() == 1)
    {
      $registro = $query->row();

      return $registro;
    }

    $this->session->set_flashdata('error', 'Error, datos incorrectos. Intente nuevamente.');
    redirect(base_url('login'));
  }

  public function ObtenerPermisosPerfil($idPerfil)
  {
    $this->db->where('idPerfil',$idPerfil);
    $this->db->from('cdb_perfil_x_permiso');

    $query = $this->db->get();

    if($query->num_rows() > 0)
    {
      return $query->result();
    }

    $this->session->set_flashdata('error', 'Error de sistema, consulte con el adminstrador del sitio.');
    redirect(base_url('login'));
  }

  public function ObtenerUsuarios()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerUsuarioPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,'idUsuario',$valorFiltro);
  }

  public function InsertarUsuario($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarUsuario($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,'idUsuario',$valorFiltro);
  }

  public function EliminarUsuario($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,'idUsuario',$valorFiltro);
  }
}

?>
