<?php

require_once APPPATH . 'core/Mantenimientos.php';

class ProyectoModel extends CI_Model
{
    public $nombreTabla = 'cdb_Area';

    public function __construct() {
       parent::__construct();
 
       $this->load->helper('security');
       $this->load->database();
    }
 
    public function getAreas (){
       $resultado = $this->db->query('call cdb_Area_Seleccionar_Comb');
       return $resultado->result();
    }

    public function guardaProyecto($Datos){
      //$resultado = $this->db->insert('cdb_area',$Datos);
      $resultado =  $this->db->query("call cdb_Proyecto_Insertar(?,?,?,?)",$Datos);
      if($resultado = 1){
         return true;

      }else{
         return false;
      }
   }

}
