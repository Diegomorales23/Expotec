<?php

require_once APPPATH . 'core/Mantenimientos.php';

class PerfilModel extends CI_Model
{


  public $nombreTabla = 'cdb_perfil';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }


  public function ObtenerPerfil()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerPerfilPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,'idPerfil',$valorFiltro);
  }

  public function InsertarPerfil($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarPerfil($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,'idPerfil',$valorFiltro);
  }

  public function EliminarPerfil($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,'idPerfil',$valorFiltro);
  }
}

?>
