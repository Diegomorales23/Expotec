<?php

require_once APPPATH . 'core/Mantenimientos.php';

class ContactoModel extends CI_Model
{
  public $nombreTabla = 'cdb_contacto';
  public $nombreCampo = 'idContacto';

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }

  public function ObtenerContacto()
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Obtener($this->nombreTabla);
  }

  public function ObtenerContactoPorId($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->ObtenerPorId($this->nombreTabla,$this->nombreCampo,$valorFiltro);
  }

  public function InsertarContacto($pDatos)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Insertar($this->nombreTabla,$pDatos);
  }

  public function ActualizarContacto($pDatos,$valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Actualizar($this->nombreTabla,$pDatos,$this->nombreCampo,$valorFiltro);
  }

  public function EliminarContacto($valorFiltro)
  {
    $this->Mantenimientos = new Mantenimientos;
    return $this->Mantenimientos->Eliminar($this->nombreTabla,$this->nombreCampo,$valorFiltro);
  }
}

?>
