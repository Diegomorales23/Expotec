<?php
/********** MANTENIMIENTO PARA TABLAS **********
/*
  mantenimientos para las tablas que lo requieran.
  los metodos piden el nombre de la tabla, campos para filtro y los valores
  en orden. Ningun valor debe ir nulo.
  $pTabla = nombre de la tabla a la que se hace referencia
  $pDatos = lista de los datos ha enviar
  $campoFiltro = nombre del campo de la tabla a filtar mediante el where
  $valorFiltro = valor del filtro
*/
/*************************************************/

class Mantenimientos extends CI_Model
{

  public $estadoActivo = 1;

  public function __construct() {
	 parent::__construct();

  $this->load->helper('security');
  $this->load->database();
 }

  public function Obtener($pTabla)
  {
    $this->db->from($pTabla);
    $query = $this->db->get();

    if($query->num_rows() > 0)
    {
      return $query->result();
    }
  }

  public function ObtenerPorId($pTabla,$campoFiltro,$valorFiltro)
  {
    $this->db->where($campoFiltro,$valorFiltro);
    $this->db->from($pTabla);

    $query = $this->db->get();

    if($query->num_rows() > 0)
    {
      return $query->result();
    }
  }

  public function Insertar($pTabla,$pDatos)
  {
      $resultado = $this->db->insert( $pTabla, $pDatos);
      return $resultado;
  }

  public function Actualizar($pTabla,$pDatos,$campoFiltro,$valorFiltro)
  {
      $this->db->set($pDatos);
      $this->db->where($campoFiltro, $valorFiltro);
      $resultado = $this->db->update( $pTabla, $pDatos);
      return $resultado;
  }

  public function Eliminar($pTabla,$campoFiltro,$valorFiltro)
  {
    if ($this->db->delete( $pTabla, $campoFiltro . ' = '. $valorFiltro))
    {
      return true;
    }
    return false;
  }
}
