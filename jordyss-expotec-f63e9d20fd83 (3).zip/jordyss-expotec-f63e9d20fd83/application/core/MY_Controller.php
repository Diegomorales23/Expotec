<?php
class MY_Controller extends CI_Controller {
  public function __construct()
  {
    parent::__construct();
    $this->load->helper('security');
    $this->load->library('encryption');
    $this->load->library('Session');
  }

  public function ObtenerMasterPage($pRuta,$pScript=null, $pNombreDatos=null,$pDatos=null)
  {
    if($this->session->userdata['logged_in'])
    {
      $data['nombreUsuario'] = $this->session->userdata['logged_in']['nombre'];
      if(isset($pScript))
      {
        $data['script']= $pScript;
      }

      if(isset($pDatos))
      {
        $data[$pNombreDatos]= $pDatos;
      }

      $this->load->view('Administracion/header');
      $this->load->view('Administracion/sidebar',$data);
      $this->load->view($pRuta,$data);
      $this->load->view('Administracion/footer');
    }
    else {
      redirect(base_url());
    }
  }

  /*
  *Metodo que ayuda a enviar correos segun lo requerido en el sistema
  *$email = email del usuario al que le llegará el correo
  *$pTitulo = titulo para el correo
  *$pAsunto = asunto que lleva el correo
  *$pMensaje = cuerpo del mensaje (preferiblemente html)
  */
  function EnviarCorreo($email,$pTitulo,$pAsunto,$pMensaje,$pMesajeRespuesta) {
    $this->load->config('email');

    $this->email->set_newline("\r\n");
    $config = array();
    $config['protocol'] = $this->config->item('protocol');
    $config['smtp_host'] = $this->config->item('smtp_host');
    $config['smtp_user'] = $this->config->item('smtp_user');
    $config['smtp_pass'] = $this->config->item('smtp_pass');
    $config['smtp_port'] = $this->config->item('smtp_port');
    $config['smtp_crypto'] = $this->config->item('smtp_crypto');
    $config['wordwrap'] = $this->config->item('wordwrap');
    $config['mailtype'] = $this->config->item('mailtype');
    $config['newline'] = $this->config->item('newline');
    $config['crlf'] = $this->config->item('crlf');

    $this->email->initialize($config);

    $this->email->from($this->config->item('smtp_user'), $pTitulo);
    $this->email->to($email);
    $this->email->subject($pAsunto);
    $this->email->message($pMensaje);

    if($this->email->send())
        return $pMesajeRespuesta;
    else
      return ERROR_ENVIO_CORREO;
  }
}
