$('#btnGuardarProyecto').on('click',function(){
   var datos= {}; 
   var Nombre = $("#txtNombreProyecto").val();
   var idArea =  $("#ddArea").val();
   var descripcion =  $("#txtDescripcion").val();
   var grado =  $("#txtGrado").val();

    alert(Nombre);
    alert(idArea);
    alert(descripcion);
    $.ajax({
        url: baseurl + "Proyecto/Guardar",
        type: "POST",
        data: {'Nombre' : Nombre,
               'idArea' : idArea, 
               'Descripcion' : descripcion,
               'Grado' : grado
            },
        dataType: "json",
        success: function (data) {
            swal("","Se guardó correctamente","success");
               // return false;
            },
        error: function (xhr, ajaxOptions, thrownError) {
            alert("Da error");
            swal("","Error, intente nuevamente.","error");
        }        
    })
});


function CargarTablaUsuarios (){
    tblAreas = $('#tbl-areas').DataTable( {
        language: {
            "search": "Buscar:"
        },
        "bPaginate": false,
        "bFilter": true,
        "bInfo": false,
        "ajax": {
            url : baseurl + "Mantenimientos/proyectos/GetTable",
            type : 'GET'
        },
        "columns": [
            { "data": "id" },
            { "data": "Nombre" },
            {
                data: "ind_asignado",
                render:function(data, type, row){
                    return "<input type='checkbox' class='custom-control-input' id='tableDefaultCheck1'>"
                }
            }
        ]
    }); 
}