var dtUsuarios = null;

$(document).ready(function () {

  dtUsuarios = $('#id_table').DataTable({
    'language': "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json",
    'info': false,
    'processing': true,
    'ordering': true,
    'lengthChange': false,
    'rowCallback': options.rowCallback,
  });

  $('#id_table tbody').on('click','#idEliminar',function(){
    swal({
        title: "¿Desea eliminar el usuario?",
        text: "",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                var data = dtUsuarios.row($(this).parents('tr')).data();
                $.ajax({
                    url: "usuario/EliminarUsuario",
                    type: "POST",
                    data: { "idUsuario": data[0] },
                    datatype: "json",
                    success: function (data) {
                    swal("", data.mensaje, data.accion);
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                          alert(thrownError);
                    }
                });
            }
        });
  });

  $('#id_table tbody').on('click','#idDetalle',function(){
    var data = dtUsuarios.row($(this).parents('tr')).data();
    $.ajax({
        url: "usuario/ObtenerUsuarioPorId",
        type: "POST",
        data: { "idUsuario": data[0] },
        datatype: "json",
        success: function (data) {
          $('#idDatosDetalleUsuario').empty();
          $('#idDatosDetalleUsuario').append('<div class="col-12"><strong><label>Nombre:</label></strong><label>' + data[0].nombre  + '</label></div>');
          $('#idDatosDetalleUsuario').append('<div class="col-12"><strong><label>Apellidos:</label></strong><label>' + data[0].apellido1  + '</label></div>');
          $('#idDatosDetalleUsuario').append('<div class="col-12"><strong><label>Correo:</label></strong><label>' + data[0].correo  + '</label></div>');
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#id_table tbody').on('click','#idEditar',function(){
    var data = dtUsuarios.row($(this).parents('tr')).data();
    $.ajax({
        url: "usuario/ObtenerUsuarioPorId",
        type: "POST",
        data: { "idUsuario": data[0] },
        datatype: "json",
        success: function (data) {
        $('#idDatosEditarUsuario form').empty();
        $('#idDatosEditarUsuario form').append('<input type="hidden" id="idUsuarioD" name="id" value="'+ data[0].idUsuario +'">');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Nombre:</label></strong><input class="form-control" type="text" name="nombre" value="'+ data[0].nombre +'"></div>');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Apellidos:</label></strong><input class="form-control" type="text" name="apellido1" value="'+ data[0].apellido1 +'"></div>');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Correo:</label></strong><input class="form-control" type="mail" name="correo" value="'+ data[0].correo +'"></div>');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Clave:</label></strong><input class="form-control" type="password" name="clave" value="'+ data[0].clave +'"></div>');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Pefil:</label></strong><select class="form-control" name="idPerfil" id="idPerfil"></select></div>');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Estado:</label></strong><select class="form-control" name="idEstado" id="idEstado"></select></div>');

        cargarPerfil('#idPerfil',data[0].idPerfil);
        cargarEstado('#idEstado',data[0].idEstado);

        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#btnEditar').on('click',function(){

    var datos = ObtenerDatosEditar();
    $.ajax({
        url: "usuario/ActualizarUsuario",
        type: "POST",
        data: datos,
        datatype: "json",
        success: function (data) {
            swal("",data.mensaje,data.accion);
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#btnAgregar').on('click',function(){
    var datos = {};
    $("#idDatosInsertar input").each(function (index, valor) {
      var nombre = valor.name;
        if (nombre != "")
              datos[nombre] = valor.value;
    });

    $("#idDatosInsertar select").each(function (index, valor) {
      var nombre = valor.name;
        if (nombre != "")
            datos[nombre] = $(this).children("option:selected").val();
    });

    $.ajax({
        url: "usuario/InsertarUsuario",
        type: "POST",
        data: datos,
        datatype: "json",
        success: function (data) {
            swal("",data.mensaje,data.accion);
        },
        error: function (xhr, ajaxOptions, thrownError) {
              swal("","Error, intente nuevamente.","error");
        }
    });

  });

  });


function cargarPerfil(idSelect,valor){
  $.ajax({
      url: "usuario/ObtenerPerfil",
      type: "POST",
      datatype: "json",
      success: function (data) {

        $.each(data, function(index, value) {
          $(idSelect).append($("<option />").val(value.idPerfil).text(value.nombre));
        });

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
$(idSelect).find('option[value="2"]').attr('selected','selected')
}

function cargarEstado(idSelect,valor){
  $.ajax({
      url: "usuario/ObtenerEstado",
      type: "POST",
      datatype: "json",
      success: function (data) {

        $.each(data, function(index, value) {
          $(idSelect).append($("<option />").val(value.idEstado).text(value.nombre));
        });

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
$(idSelect).find('option[value="2"]').attr('selected','selected')
}

function ObtenerDatosEditar(){
  var datos = {};

  datos['idUsuario'] = $("#idUsuarioD").val();

  $("#idDatosEditarUsuario input").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
            datos[nombre] = valor.value;
  });

  $("#idDatosEditarUsuario select").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
          datos[nombre] = $(this).children("option:selected").val();
  });
console.log(datos);
  return datos;
}
