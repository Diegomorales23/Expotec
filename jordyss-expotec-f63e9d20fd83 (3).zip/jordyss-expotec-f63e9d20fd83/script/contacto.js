var dtContactos = null;

$(document).ready(function () {

  dtContactos = $('#id_table').DataTable({
    'language': "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json",
    'info': false,
    'processing': true,
    'ordering': true,
    'lengthChange': false,
    'rowCallback': options.rowCallback,
  });

  $('#id_table tbody').on('click','#idEliminar',function(){
    swal({
        title: "¿Desea eliminar la información de contacto?",
        text: "",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                var data = dtContactos.row($(this).parents('tr')).data();
                $.ajax({
                    url: "contacto/EliminarContacto",
                    type: "POST",
                    data: { "id": data[0] },
                    datatype: "json",
                    success: function (data) {
                    swal("", data.mensaje, data.accion);
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                          alert(thrownError);
                    }
                });
            }
        });
  });

  $('#id_table tbody').on('click','#idDetalle',function(){
    var data = dtContactos.row($(this).parents('tr')).data();
    $.ajax({
        url: "contacto/ObtenerContactoPorId",
        type: "POST",
        data: { "id": data[0] },
        datatype: "json",
        success: function (data) {
          console.log(data);
          $('#idDatosDetalleContacto').empty();
          $('#idDatosDetalleContacto').append('<div class="col-12"><strong><label>Nombre:</label></strong><label>' + data[0].nombre  + '</label></div>');
          $('#idDatosDetalleContacto').append('<div class="col-12"><strong><label>Correo electrónico:</label></strong><label>' + data[0].correo  + '</label></div>');
          $('#idDatosDetalleContacto').append('<div class="col-12"><strong><label>Fecha de envío:</label></strong><label>' + data[0].fecha  + '</label></div>');
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#btnAgregar').on('click',function(){
    var datos = {};
    $("#idDatosInsertar input").each(function (index, valor) {
      var nombre = valor.name;
        if (nombre != "")
              datos[nombre] = valor.value;
    });

    $.ajax({
        url: "contacto/InsertarContacto",
        type: "POST",
        data: datos,
        datatype: "json",
        success: function (data) {
            swal("",data.mensaje,data.accion);
        },
        error: function (xhr, ajaxOptions, thrownError) {
              swal("","Error, intente nuevamente.","error");
        }
    });
  });

  $('#id_table tbody').on('click','#idEditar',function(){
    var dataR = dtContactos.row($(this).parents('tr')).data();
    $.ajax({
        url: "contacto/ObtenerContactoPorId",
        type: "POST",
        data: { "id": dataR[0] },
        datatype: "json",
        success: function (data) {
        $('#idDatosEditarUsuario form').empty();
        $('#idDatosEditarUsuario form').append('<input type="hidden" name="id" value="'+ dataR[0] +'">');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Nombre:</label></strong><input class="form-control" type="text" name="nombre" value="'+ data[0].nombre +'"></div>');
        $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Correo:</label></strong><input class="form-control" type="mail" name="correo" value="'+ data[0].correo +'"></div>');
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#btnEditar').on('click',function(){

    var datos = ObtenerDatosEditar();
    $.ajax({
        url: "contacto/ActualizarContacto",
        type: "POST",
        data: datos,
        datatype: "json",
        success: function (data) {
            swal("",data.mensaje,data.accion);
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });
  });


function cargarPerfil(idSelect,valor){
  $.ajax({
      url: "ObtenerPerfil",
      type: "POST",
      datatype: "json",
      success: function (data) {

        $.each(data, function(index, value) {
          $(idSelect).append($("<option />").val(value.id).text(value.nombre));
        });

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
$(idSelect).find('option[value="2"]').attr('selected','selected')
}

function cargarEstado(idSelect,valor){
  $.ajax({
      url: "ObtenerEstado",
      type: "POST",
      datatype: "json",
      success: function (data) {

        $.each(data, function(index, value) {
          $(idSelect).append($("<option />").val(value.id).text(value.nombre));
        });

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
$(idSelect).find('option[value="2"]').attr('selected','selected')
}

function ObtenerDatosEditar(){
  var datos = {};

  datos['id'] = $("#idDatosEditarUsuario hidden").value
  $("#idDatosEditarUsuario input").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
            datos[nombre] = valor.value;
  });

  return datos;
}
