var dtEventos = null;

$(document).ready(function () {
  dtEventos = $('#id_table').DataTable({
    'language': "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json",
    'info': false,
    'processing': true,
    'ordering': true,
    'lengthChange': false,
    'rowCallback': options.rowCallback,
  });

$('#id_table tbody').on('click','#idEliminar',function(){
  swal({
      title: "¿Desea eliminar el evento?",
      text: "",
      icon: "warning",
      buttons: true,
      dangerMode: true,
  })
      .then((willDelete) => {
          if (willDelete) {
              var data = dtEventos.row($(this).parents('tr')).data();
              $.ajax({
                  url: "evento/eliminarevento",
                  type: "POST",
                  data: { "idEvento": data[0] },
                  datatype: "json",
                  success: function (data) {
                  swal("", data.mensaje, data.accion);
                  },
                  error: function (xhr, ajaxOptions, thrownError) {
                        alert(thrownError);
                  }
              });
          }
      });
});

$('#id_table tbody').on('click','#idDetalle',function(){
  var data = dtEventos.row($(this).parents('tr')).data();
  $.ajax({
      url: "evento/obtenereventoporid",
      type: "POST",
      data: { "idEvento": data[0] },
      datatype: "json",
      success: function (data) {
        $('#idDatosDetalleEvento').empty();
        $('#idDatosDetalleEvento').append('<div class="col-12 text-center"><img src="http://localhost:8080/expotec'+ data[0].imagen +'" alt="img-'+ data[0].titulo  +'" style="width: 300px; margin-bottom: 20px;"></div>');
        $('#idDatosDetalleEvento').append('<div class="col-12"><strong><label>Titulo:</label></strong><label>' + data[0].titulo  + '</label></div>');
        $('#idDatosDetalleEvento').append('<div class="col-12"><strong><label>Descripción:</label></strong><label>' + data[0].descripcion  + '</label></div>');
        $('#idDatosDetalleEvento').append('<div class="col-12"><strong><label>Horario:</label></strong><label>' + data[0].horario  + '</label></div>');
        $('#idDatosDetalleEvento').append('<div class="col-12"><strong><label>Lugar:</label></strong><label>' + data[0].lugar  + '</label></div>');
        $('#idDatosDetalleEvento').append('<div class="col-12"><strong><label>Cupos:</label></strong><label>' + data[0].cupos  + '</label></div>');

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
});

$('#id_table tbody').on('click','#idEditar',function(){
  var data = dtEventos.row($(this).parents('tr')).data();
  $.ajax({
      url: "evento/obtenereventoporid",
      type: "POST",
      data: { "idEvento": data[0] },
      datatype: "json",
      success: function (data) {
      $('#idDatosEditarUsuario form').empty();
      $('#idDatosEditarUsuario form').append('<input type="hidden" name="id" value="'+ data[0].idEvento +'">');
      $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Titulo:</label></strong><input class="form-control" type="text" name="titulo" value="'+ data[0].titulo +'"></div>');
      $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Descripción:</label></strong><input class="form-control" type="text" name="descripcion" value="'+ data[0].descripcion +'"></div>');
      $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Horario:</label></strong><input class="form-control" type="text" name="horario" value="'+ data[0].horario +'"></div>');
      $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Lugar:</label></strong><input class="form-control" type="text" name="lugar" value="'+ data[0].lugar +'"></div>');
      $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Estado:</label></strong><select class="form-control" name="idEstado" id="idEstado"></select></div>');
      $('#idDatosEditarUsuario form').append('<div class="col-12"><strong><label>Cupo:</label></strong><input class="form-control" type="text" name="cupo" value="'+ data[0].cupos +'"></div>');

      cargarEstado('#idEstado',data[0].idEstado);

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
});

$('#btnEditar').on('click',function(){

  var datos = ObtenerDatosEditar();
  $.ajax({
      url: "evento/actualizarevento",
      type: "POST",
      data: datos,
      datatype: "json",
      success: function (data) {
          swal("",data.mensaje,data.accion);
      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
});

});

function CargarTablaAreas (){
    //$('#id_table').DataTable().fnDestroy();
    dtEventos = $('#id_table').DataTable({
        "bPaginate": false,
        "bFilter": false,
        "bInfo": false,
        "ajax": {
            url : "../mantenimiento/evento/obtenerEvento",
            type : 'GET'
        },
        "columns": [
            { "data": "id",  "bVisible": false },
            { "data": "nombre" },
            { "data": "urlImagen" },
            {
                data: null,
                render:function(data, type, row){
                    return "<button onclick='Seleccionar_datos(" + row.idArea + "); return false;'> Seleccionar </button>"
                }
            }
        ]
    });
}

function cargarEstado(idSelect,valor){
  $.ajax({
      url: "usuario/ObtenerEstado",
      type: "POST",
      datatype: "json",
      success: function (data) {

        $.each(data, function(index, value) {
          $(idSelect).append($("<option />").val(value.id).text(value.nombre));
        });

      },
      error: function (xhr, ajaxOptions, thrownError) {
            alert(thrownError);
      }
  });
$(idSelect).find('option[value="2"]').attr('selected','selected')
}

function ObtenerDatosEditar(){
  var datos = {};

  datos['idEvento'] = $("#idDatosEditarUsuario hidden").value;

  $("#idDatosEditarUsuario input").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
            datos[nombre] = valor.value;
  });

  $("#idDatosEditarUsuario select").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
          datos[nombre] = $(this).children("option:selected").val();
  });

  return datos;
}
