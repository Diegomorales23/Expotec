var tblAreas = null;
var filaSeleccionada = null;

function EliminarArea()
{
    if(filaSeleccionada == null)    
    {
        alert("Seleccione un registro");
        return;
    }
}
function CargarAreaFormulario(area)
{
    $("#idArea").val(area.idArea);
    $("#txtNombreArea").val(area.Nombre);
    $("#txtDescripcion").val(area.Descripcion);
    $("#ddCoordinador").val(area.IdCoordinador);
    return false;
}

function CargarTablaAreas (){
    tblAreas = $('#tbl-areas').DataTable( {
        language: {
            "search": "Buscar:"
        },
        "bPaginate": false,
        "bFilter": true,
        "bInfo": false,
        "ajax": {
            url : baseurl + "Mantenimientos/Areas/GetTable",
            type : 'GET'
        },
        "columns": [
            { "data": "idArea" },
            { "data": "Nombre" },
            { "data": "Descripcion" },
            { "data": "NombreCoordinador"},
            { "data": "IdCoordinador" , "visible": false },
            {
                data: null,
                render:function(data, type, row){
                    return "<a class='table-btn' id='btnEditar' href=='#'><i class='fas fa-edit'></i></a>"
                }
            },
            {
                data: null,
                render:function(data, type, row){
                    return "<a class='table-btn' id='btnEliminar' href=='#'><i class='fas fa-trash-alt'></i></a>"
                }
            }
        ]
    }); 
}

$(document).ready(function () {
    CargarTablaAreas();

});

$('#tbl-areas tbody').on('click','#btnEditar',function(){
    var data = tblAreas.row($(this).parents('tr')).data();
    filaSeleccionada =  data; //tblAreas.row(this).data();
    CargarAreaFormulario(filaSeleccionada);
    return false;
});

$('#btnGuardarArea').on('click',function(){
    var datos = {};
    $("#DatosArea input").each(function (index, valor) {
        var nombre = valor.name;
        if (nombre != "") {
            datos[nombre] = valor.value;
            alert(nombre);
            alert(valor.value);
        }
    });

    $("#DatosArea select").each(function (index, valor) {
        var nombre = valor.name;
        if (nombre != ""){
            datos[nombre] = $(this).children("option:selected").val();
            alert(nombre);
            alert($(this).children("option:selected").val());
        }
    });

    $("#DatosArea textarea").each(function (index, valor) {
        var nombre = valor.name;
        if (nombre != ""){
            datos[nombre] = valor.value;
            alert(nombre);
            alert(valor.value);
        }
    });

    alert(datos);
    console.log(datos);
    if (datos['idArea'] == '' || datos['idArea'] == null)   {
        InsertarArea(datos);
    }else{
        ActualizarArea(datos);
    }
   
});

function InsertarArea(datos){
    console.log(datos);
    $.ajax({
        url: baseurl + "Mantenimientos/Areas/Insertar",
        type: "POST",
        data: datos,
        dataType: "json",
        success: function (data) {
            swal("", data.mensaje, data.accion);
            CargarTablaAreas();
          
            },
        error: function (xhr, ajaxOptions, thrownError) {
            alert("Da error");
            swal("","Error, intente nuevamente.","error");
        }        
    })
}

function ActualizarArea(datos){
    $.ajax({
        url: baseurl + "Mantenimientos/Areas/Actualizar",
        type: "POST",
        data: datos,
        dataType: "json",
        success: function (data) {
            swal("", data.mensaje, data.accion);
            CargarTablaAreas();
            },
        error: function (xhr, ajaxOptions, thrownError) {
            alert("Da error");
            swal("","Error, intente nuevamente.","error");
        }        
    })
}

$('#tbl-areas tbody').on('click','#btnEliminar',function(){
    var data = tblAreas.row($(this).parents('tr')).data();
    filaSeleccionada =  data; //tblAreas.row(this).data();

    var datos = {};
    datos['pidArea'] = filaSeleccionada.idArea;
    EliminarArea(datos);
    return false;
});

function EliminarArea(datos){
    $.ajax({
        url: baseurl + "Mantenimientos/Areas/Eliminar",
        type: "POST",
        data: datos,
        dataType: "json",
        success: function (data) {
            swal("", data.mensaje, data.accion);
             CargarTablaAreas();
            },
        error: function (xhr, ajaxOptions, thrownError) {
            alert("Da error");
            swal("","Error, intente nuevamente.","error");
        }        
    })
}
