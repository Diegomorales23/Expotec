var dtPerfiles = null;

$(document).ready(function () {

  dtPerfiles = $('#id_table').DataTable({
    'language': "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json",
    'info': false,
    'processing': true,
    'ordering': true,
    'lengthChange': false,
    'rowCallback': options.rowCallback,
  });

  $('#id_table tbody').on('click','#idEliminar',function(){
    swal({
        title: "¿Desea eliminar el perfil?",
        text: "",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                var data = dtPerfiles.row($(this).parents('tr')).data();
                $.ajax({
                    url: "perfil/EliminarPerfil",
                    type: "POST",
                    data: { "idPerfil": data[0] },
                    datatype: "json",
                    success: function (data) {
                    swal("", data.mensaje, data.accion);
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                          alert(thrownError);
                    }
                });
            }
        });
  });

  $('#id_table tbody').on('click','#idDetalle',function(){
    var data = dtPerfiles.row($(this).parents('tr')).data();
    $.ajax({
        url: "perfil/ObtenerPerfilPorId",
        type: "POST",
        data: { "idPerfil": data[0] },
        datatype: "json",
        success: function (data) {
          console.log(data);
          $('#idDatosDetallePerfil').empty();
          $('#idDatosDetallePerfil').append('<div class="col-12"><strong><label>Nombre:</label></strong><label>' + data[0].nombre  + '</label></div>');
          $('#idDatosDetallePerfil').append('<div class="col-12"><strong><label>Descripcion:</label></strong><label>' + data[0].descripcion  + '</label></div>');
          //$('#idDatosDetallePerfil').append('<div class="col-12"><strong><label>Estado:</label></strong><label>' + data.estado  + '</label></div>');
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#id_table tbody').on('click','#idEditar',function(){
    var data = dtPerfiles.row($(this).parents('tr')).data();
    $.ajax({
        url: "perfil/ObtenerPerfilPorId",
        type: "POST",
        data: { "idPerfil": data[0] },
        datatype: "json",
        success: function (data) {
        $('#idDatosEditarPerfil form').empty();
        $('#idDatosEditarPerfil form').append('<input type="hidden" name="idPerfil" value="'+ data[0].idPerfil +'">');
        $('#idDatosEditarPerfil form').append('<div class="col-12"><strong><label>Nombre:</label></strong><input class="form-control" type="text" name="nombre" value="'+ data[0].nombre +'"></div>');
        $('#idDatosEditarPerfil form').append('<div class="col-12"><strong><label>Descripcion:</label></strong><input class="form-control" type="text" name="descripcion" value="'+ data[0].descripcion +'"></div>');
        $('#idDatosEditarPerfil form').append('<div class="col-12"><strong><label>Estado:</label></strong><select class="form-control" name="idEstado" id="idEstado"></select></div>');

        cargarEstado('#idEstado',data[0].idEstado);

        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#btnEditar').on('click',function(){

    var datos = ObtenerDatosEditar();
    $.ajax({
        url: "perfil/ActualizarPerfil",
        type: "POST",
        data: datos,
        datatype: "json",
        success: function (data) {
            swal("",data.mensaje,data.accion);
        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  });

  $('#btnAgregar').on('click',function(){
    var datos = {};
    $("#idDatosInsertar input").each(function (index, valor) {
      var nombre = valor.name;
        if (nombre != "")
              datos[nombre] = valor.value;
    });

    $("#idDatosInsertar select").each(function (index, valor) {
      var nombre = valor.name;
        if (nombre != "")
            datos[nombre] = $(this).children("option:selected").val();
    });

    $.ajax({
        url: "perfil/InsertarPerfil",
        type: "POST",
        data: datos,
        datatype: "json",
        success: function (data) {
            swal("",data.mensaje,data.accion);
        },
        error: function (xhr, ajaxOptions, thrownError) {
              swal("","Error, intente nuevamente.","error");
        }
    });

  });

  });

  function cargarEstado(idSelect,valor){
    $.ajax({
        url: "usuario/ObtenerEstado",
        type: "POST",
        datatype: "json",
        success: function (data) {

          $.each(data, function(index, value) {
            $(idSelect).append($("<option />").val(value.idEstado).text(value.nombre));
          });

        },
        error: function (xhr, ajaxOptions, thrownError) {
              alert(thrownError);
        }
    });
  $(idSelect).find('option[value="2"]').attr('selected','selected')
  }

function ObtenerDatosEditar(){
  var datos = {};

  datos['idPerfil'] = $("#idDatosEditarPerfil hidden").value;

  $("#idDatosEditarPerfil input").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
            datos[nombre] = valor.value;
  });

  $("#idDatosEditarPerfil select").each(function (index, valor) {
    var nombre = valor.name;
      if (nombre != "")
          datos[nombre] = $(this).children("option:selected").val();
  });

  return datos;
}
