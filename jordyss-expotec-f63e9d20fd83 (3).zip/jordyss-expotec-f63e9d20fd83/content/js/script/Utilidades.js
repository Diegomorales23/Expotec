new WOW().init();


var vDataTableTranslation = "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json";
var contentTypeApplication = "application/json; charset=utf-8";
var contentTypeJson = "json";
var pathUrl = location.protocol + "//" + location.host + "/";
var options = new Object();
var path = '<?php echo base_url(); ?>';

this.getDataTable = function (options) {

    return $(options.id).DataTable({
            "pageLength": options.pagination,
            //"serverSide": true, // for process server side
            "processing": true, // for show progress bar
            "filter": options.search, // this is for disable filter (search box)
            "responsive": true,
            "ajax": {
                "url": options.url,
                "type": "POST",
                "datatype": "json",
                "data": options.data,
                "error": function (jqXHR, exception) {
                    alert(jqXHR + " - " + exception);
                },
            },
            "columnDefs": options.responsive,
            "columns": options.columns,
            "ordering": true,
            "lengthChange": false,
            "language": {
                "url": vDataTableTranslation,
            },
            "rowCallback": options.rowCallback
        });
}

var Utilidades = new function () {
    //Funcion que realiza la peticion al servidor y retorna los datos por medio de otra funcion
    this.getDatos = function (options) {
        /// parametro url: ruta en el servidor del controlador y metodo
        /// parametro data: parametro solicitado por el metodo en el servidor [opcional]
        /// parametro callback: funcion que me permite transferir los datos para su procesamiento
        $.ajax({
            url: options.url,
            data: options.data,
            dataType: options.dataType,
            contentType: options.contentType,
            type: options.type,
            success: options.callback,
            error: options.callbackError
        });
    };

    this.procesarRespuestaError = function () {
        swal("Error!", "Error al procesar la solicitud, intente más tarde.", "error");
    };

    this.procesarRespuesta = function (title, response, type) {
        swal(title, response, type);
    };
};
