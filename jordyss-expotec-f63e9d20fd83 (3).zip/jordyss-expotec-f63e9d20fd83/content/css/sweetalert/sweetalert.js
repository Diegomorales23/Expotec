/*
 * This makes sure that we can use the global
 * swal() function, instead of swal.default()
 * See: https://github.com/webpack/webpack/issues/3929
 */

//var full = location.protocol + '//' + location.hostname + (location.port ? ':' + location.port : '');

//if (typeof window !== 'undefined') {
//    require(full + '/Content/sweetalert/sweetalert.css');
//}

//require('./polyfills');

//var swal = require('./core').default;

//module.exports = swal;
